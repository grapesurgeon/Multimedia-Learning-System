(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Linear Search_atlas_", frames: [[478,1008,208,81],[0,576,1192,142],[1302,880,52,57],[1194,913,52,57],[780,1144,30,57],[748,1144,30,57],[1400,0,52,57],[1356,349,52,57],[1306,998,52,57],[226,1085,52,57],[0,1008,304,75],[716,1144,30,57],[684,1150,30,57],[652,1150,30,57],[620,1150,30,57],[588,1150,30,57],[556,1150,30,57],[524,1150,30,57],[492,1150,30,57],[0,1085,170,130],[306,1008,170,130],[1194,231,90,90],[0,864,1192,142],[1194,854,52,57],[1302,821,52,57],[396,1199,30,57],[428,1199,30,57],[1248,880,52,57],[1248,939,52,57],[1302,939,52,57],[172,1085,52,57],[1194,154,204,75],[894,1085,30,57],[958,1085,30,57],[702,1085,30,57],[670,1091,30,57],[606,1091,30,57],[574,1091,30,57],[542,1091,30,57],[510,1091,30,57],[0,288,1192,142],[1194,618,52,57],[1248,585,52,57],[428,1140,30,57],[396,1140,30,57],[1302,526,52,57],[1194,559,52,57],[1248,526,52,57],[1302,467,52,57],[1100,1008,204,75],[364,1140,30,57],[734,1085,30,57],[830,1085,30,57],[798,1085,30,57],[638,1091,30,57],[766,1085,30,57],[990,1085,30,57],[862,1085,30,57],[0,432,1192,142],[1302,585,52,57],[1248,644,52,57],[926,1085,30,57],[1356,821,30,57],[1340,290,52,57],[1302,408,52,57],[1340,231,52,57],[1302,349,52,57],[894,1008,204,75],[332,1140,30,57],[300,1140,30,57],[268,1144,30,57],[236,1144,30,57],[172,1144,30,57],[204,1144,30,57],[478,1091,30,57],[1306,1057,30,57],[0,144,1192,142],[1194,382,52,57],[1194,500,52,57],[1356,939,30,57],[1356,880,30,57],[1248,467,52,57],[1194,441,52,57],[1248,408,52,57],[1248,349,52,57],[688,1008,204,75],[1356,467,30,57],[1356,585,30,57],[1400,118,30,57],[1356,408,30,57],[1356,644,30,57],[1356,526,30,57],[1400,177,30,57],[1394,236,30,57],[0,0,1192,142],[1286,290,52,57],[1194,323,52,57],[1356,762,30,57],[1356,703,30,57],[1286,231,52,57],[1194,795,52,57],[1302,762,52,57],[1248,821,52,57],[1194,77,204,75],[268,1203,30,57],[300,1199,30,57],[332,1199,30,57],[364,1199,30,57],[1400,59,30,57],[1022,1085,30,57],[1054,1085,30,57],[1086,1085,30,57],[0,720,1192,142],[1194,677,52,57],[1302,644,52,57],[1118,1116,30,57],[460,1150,30,57],[1248,703,52,57],[1194,736,52,57],[1302,703,52,57],[1248,762,52,57],[1194,0,204,75],[172,1203,30,57],[0,1217,30,57],[32,1217,30,57],[64,1217,30,57],[96,1217,30,57],[128,1217,30,57],[204,1203,30,57],[236,1203,30,57]]}
];


// symbols:



(lib.CachedTexturedBitmap_172 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_173 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_174 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_175 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_176 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_177 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_178 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_179 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_180 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_181 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_182 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_183 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_184 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_185 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_186 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_187 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_188 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_189 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_190 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_191 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_192 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_194 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_195 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_196 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_197 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_198 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_199 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_200 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_201 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_202 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_203 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_204 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_205 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_206 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_207 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_208 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_209 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_210 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_211 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_212 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_213 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_214 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_215 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_216 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_217 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_218 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_219 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_220 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_221 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_222 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_223 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_224 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_225 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_226 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_227 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_228 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_229 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_230 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_231 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_232 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_233 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_234 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_235 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_236 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_237 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_238 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_239 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_240 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_241 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_242 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_243 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_244 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_245 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_246 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_247 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_248 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_249 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_250 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_251 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_252 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_253 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_254 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_255 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_256 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_257 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_258 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_259 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_260 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_261 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_262 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_263 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_264 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_265 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_266 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_267 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_268 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_269 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_270 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_271 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_272 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_273 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_274 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_275 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_276 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_277 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_278 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_279 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_280 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_281 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_282 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_283 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_284 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_285 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_286 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_287 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_288 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_289 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_290 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_291 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_292 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_293 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_294 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_295 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_296 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_297 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_298 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_299 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_300 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_301 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_302 = function() {
	this.initialize(ss["Linear Search_atlas_"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_302();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_301();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_300();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_299();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_298();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_297();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_296();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_295();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_294();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_293();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_292();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_291();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_290();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_289();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_288();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_287();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_286();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_285();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_284();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_283();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_282();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_281();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_280();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_279();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_278();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_277();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_276();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_275();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_274();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_273();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_272();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_271();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_270();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_269();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_268();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_267();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_266();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_265();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_264();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_263();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_262();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_261();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_260();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_259();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_258();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_257();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_256();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_255();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_254();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_253();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_252();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_251();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_250();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_249();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_248();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_247();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_246();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_245();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_244();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_243();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_242();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_241();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_240();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_239();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_238();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_237();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_236();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_235();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_234();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_233();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_232();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_231();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_230();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_229();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_228();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_227();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_226();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_225();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_224();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_223();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_222();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_221();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_220();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_219();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_218();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_217();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_216();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_215();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_214();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_213();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_212();
	this.instance.parent = this;
	this.instance.setTransform(313.9,211,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_211();
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.5,211,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_210();
	this.instance_2.parent = this;
	this.instance_2.setTransform(163.9,211,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_209();
	this.instance_3.parent = this;
	this.instance_3.setTransform(91.5,211,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_208();
	this.instance_4.parent = this;
	this.instance_4.setTransform(13.9,211,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_207();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-58.5,211,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_206();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-136.1,211,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_205();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-208.5,211,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_204();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-360.45,-239.35,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_203();
	this.instance_9.parent = this;
	this.instance_9.setTransform(313.9,144.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_202();
	this.instance_10.parent = this;
	this.instance_10.setTransform(241.5,144.2,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_201();
	this.instance_11.parent = this;
	this.instance_11.setTransform(163.9,144.2,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_200();
	this.instance_12.parent = this;
	this.instance_12.setTransform(91.5,144.2,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_199();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-136.1,144.2,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_198();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-208.5,144.2,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_197();
	this.instance_15.parent = this;
	this.instance_15.setTransform(13.9,144.2,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_196();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-58.5,144.2,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_195();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-235,123.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.4,-239.3,721.4,478.8);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_194();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_194();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_192();
	this.instance.parent = this;
	this.instance.setTransform(-2.5,-2.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,85,65);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_191();
	this.instance.parent = this;
	this.instance.setTransform(-2.5,-2.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,85,65);


// stage content:
(lib.LinearSearch = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(31);
		}
	}
	this.frame_59 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(61);
		}
		
		function handlePrev(){
			this.gotoAndPlay(29)
		}
	}
	this.frame_89 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(91);
		}
		
		function handlePrev(){
			this.gotoAndPlay(59)
		}
	}
	this.frame_119 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(121);
		}
		
		function handlePrev(){
			this.gotoAndPlay(89)
		}
	}
	this.frame_149 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(151);
		}
		
		function handlePrev(){
			this.gotoAndPlay(119)
		}
	}
	this.frame_179 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(30).call(this.frame_89).wait(30).call(this.frame_119).wait(30).call(this.frame_149).wait(30).call(this.frame_179).wait(1));

	// Button
	this.nextBtn = new lib.Symbol1();
	this.nextBtn.name = "nextBtn";
	this.nextBtn.parent = this;
	this.nextBtn.setTransform(910,580,1,1,0,0,0,40,30);
	new cjs.ButtonHelper(this.nextBtn, 0, 1, 1);

	this.text = new cjs.Text("int arr[]={5,8,15,27,34,45,51,68};\n\nint value=45,arrSize=8;\n\nbool found=false;\n\nfor(int i=0;i<arrSize;i++){\n\n     if(arr[i]==value){\n\n          found=true;\n\n          break;\n\n     }\n\n}\n\nif(found) printf(\"Found\\n\");\n\nelse printf(\"Not found\\n\");", "10px 'Times New Roman'");
	this.text.lineHeight = 11;
	this.text.lineWidth = 137;
	this.text.parent = this;
	this.text.setTransform(14.05,81.3);

	this.prevBtn = new lib.Symbol2();
	this.prevBtn.name = "prevBtn";
	this.prevBtn.parent = this;
	this.prevBtn.setTransform(50,580,1,1,0,0,0,40,30);
	new cjs.ButtonHelper(this.prevBtn, 0, 1, 1);

	this.instance = new lib.CachedTexturedBitmap_172();
	this.instance.parent = this;
	this.instance.setTransform(537,322.05,0.5,0.5);

	this.instance_1 = new lib.Symbol2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(50,580,1,1,0,0,0,40,30);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text},{t:this.nextBtn}]},29).to({state:[{t:this.text},{t:this.nextBtn},{t:this.prevBtn}]},30).to({state:[{t:this.text},{t:this.nextBtn},{t:this.prevBtn}]},30).to({state:[{t:this.text},{t:this.nextBtn},{t:this.prevBtn}]},30).to({state:[{t:this.text},{t:this.nextBtn},{t:this.prevBtn}]},30).to({state:[{t:this.text},{t:this.nextBtn},{t:this.instance_1},{t:this.instance}]},30).wait(1));

	// Pointer
	this.instance_2 = new lib.Tween12("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(208.6,501.15);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween13("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(280.6,501.15);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).to({_off:true,x:280.6},30).wait(121));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},30).to({x:357.2},30).to({x:429.6},30).to({x:507.2},30).to({x:579.6},30).wait(1));

	// Array
	this.instance_4 = new lib.CachedTexturedBitmap_190();
	this.instance_4.parent = this;
	this.instance_4.setTransform(723.4,486.8,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_189();
	this.instance_5.parent = this;
	this.instance_5.setTransform(651,486.8,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_188();
	this.instance_6.parent = this;
	this.instance_6.setTransform(573.4,486.8,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_187();
	this.instance_7.parent = this;
	this.instance_7.setTransform(501,486.8,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_186();
	this.instance_8.parent = this;
	this.instance_8.setTransform(423.4,486.8,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_185();
	this.instance_9.parent = this;
	this.instance_9.setTransform(351,486.8,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_184();
	this.instance_10.parent = this;
	this.instance_10.setTransform(273.4,486.8,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_183();
	this.instance_11.parent = this;
	this.instance_11.setTransform(201,486.8,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_182();
	this.instance_12.parent = this;
	this.instance_12.setTransform(49.05,36.45,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_181();
	this.instance_13.parent = this;
	this.instance_13.setTransform(723.4,420,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_180();
	this.instance_14.parent = this;
	this.instance_14.setTransform(651,420,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_179();
	this.instance_15.parent = this;
	this.instance_15.setTransform(573.4,420,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_178();
	this.instance_16.parent = this;
	this.instance_16.setTransform(501,420,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_177();
	this.instance_17.parent = this;
	this.instance_17.setTransform(273.4,420,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_176();
	this.instance_18.parent = this;
	this.instance_18.setTransform(201,420,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_175();
	this.instance_19.parent = this;
	this.instance_19.setTransform(423.4,420,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_174();
	this.instance_20.parent = this;
	this.instance_20.setTransform(351,420,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_173();
	this.instance_21.parent = this;
	this.instance_21.setTransform(174.5,399.5,0.5,0.5);

	this.instance_22 = new lib.Tween16("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(409.5,275.8);
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween17("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(409.5,275.8);
	this.instance_23._off = true;

	this.instance_24 = new lib.Tween18("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(409.5,275.8);
	this.instance_24._off = true;

	this.instance_25 = new lib.Tween19("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(409.5,275.8);
	this.instance_25._off = true;

	this.instance_26 = new lib.Tween20("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(409.5,275.8);
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween21("synched",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(409.5,275.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).to({state:[{t:this.instance_22}]},28).to({state:[{t:this.instance_23}]},30).to({state:[{t:this.instance_24}]},30).to({state:[{t:this.instance_25}]},30).to({state:[{t:this.instance_26}]},30).to({state:[{t:this.instance_27}]},30).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(29).to({_off:false},0).to({_off:true},30).wait(121));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(29).to({_off:false},30).to({_off:true},30).wait(91));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(59).to({_off:false},30).to({_off:true},30).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(89).to({_off:false},30).to({_off:true},30).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(119).to({_off:false},30).to({_off:true},30).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,952.5,612.5);
// library properties:
lib.properties = {
	id: '2EC0F2D9318F2843B3DA8AFC2DD0D1E2',
	width: 960,
	height: 640,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Linear Search_atlas_.png", id:"Linear Search_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2EC0F2D9318F2843B3DA8AFC2DD0D1E2'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;