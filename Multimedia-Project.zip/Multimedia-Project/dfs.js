(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"dfs_atlas_", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_2", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_3", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_4", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_5", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_6", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_7", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_8", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_9", frames: [[0,0,1787,1207]]},
		{name:"dfs_atlas_10", frames: [[0,0,1778,1207]]},
		{name:"dfs_atlas_11", frames: [[0,0,1778,1207]]},
		{name:"dfs_atlas_12", frames: [[0,1209,1369,731],[0,0,1778,1207]]},
		{name:"dfs_atlas_13", frames: [[0,0,1369,731],[0,733,1369,731]]},
		{name:"dfs_atlas_14", frames: [[0,733,1369,731],[0,0,1369,731]]},
		{name:"dfs_atlas_15", frames: [[0,733,1369,731],[0,0,1369,731]]},
		{name:"dfs_atlas_16", frames: [[1371,157,302,141],[1658,0,302,141],[1371,300,302,141],[1675,429,220,189],[1371,443,302,141],[1520,1331,220,189],[1508,1188,302,141],[666,1846,220,189],[1675,143,302,141],[888,1856,220,189],[1204,1045,302,141],[0,1464,220,189],[1812,1063,220,189],[0,0,1369,731],[1204,902,302,141],[666,1464,220,189],[888,1474,220,189],[0,1321,302,141],[1332,1522,220,189],[1110,1474,220,189],[1204,1188,302,141],[444,1464,220,189],[222,1464,220,189],[1675,286,302,141],[1110,1856,220,189],[1371,586,302,141],[1742,1331,220,189],[1812,872,220,189],[304,1321,302,141],[1776,1522,220,189],[1554,1522,220,189],[1508,902,302,141],[1110,1665,220,189],[0,1846,220,189],[1527,729,302,141],[1554,1713,220,189],[1776,1713,220,189],[1508,1045,302,141],[444,1846,220,189],[222,1846,220,189],[608,1321,302,141],[0,1655,220,189],[222,1655,220,189],[912,1331,302,141],[444,1655,220,189],[666,1655,220,189],[0,733,1202,586],[1216,1331,302,141],[888,1665,220,189],[1332,1713,220,189],[1204,733,321,167],[1371,0,285,155]]},
		{name:"dfs_atlas_17", frames: [[1901,573,127,189],[1452,1623,111,189],[515,1384,126,189],[1925,382,112,189],[376,764,224,141],[904,1050,127,189],[1565,1623,111,189],[387,1384,126,189],[1936,1050,112,189],[602,764,224,141],[226,1193,127,189],[1339,1623,111,189],[643,1384,126,189],[1141,1432,112,189],[1054,764,224,141],[355,1193,127,189],[1678,1623,111,189],[1000,1241,126,189],[1027,1432,112,189],[828,764,224,141],[0,1241,127,189],[1791,1623,111,189],[1128,1241,126,189],[997,1623,112,189],[452,1050,224,141],[1442,191,204,189],[129,1384,127,189],[1828,1814,111,189],[641,1575,126,189],[1111,1623,112,189],[0,1098,224,141],[1252,0,204,189],[0,1432,127,189],[811,1814,111,189],[1512,1241,126,189],[1483,1432,112,189],[1732,764,224,141],[206,191,204,189],[613,1193,127,189],[698,1814,111,189],[1384,1241,126,189],[1369,1432,112,189],[1506,764,224,141],[428,0,204,189],[1543,382,189,189],[1162,1050,127,189],[1037,1814,111,189],[1768,1241,126,189],[1711,1432,112,189],[0,955,224,141],[412,191,204,189],[1161,382,189,189],[742,1193,127,189],[924,1814,111,189],[1640,1241,126,189],[1597,1432,112,189],[376,907,224,141],[222,0,204,189],[1352,382,189,189],[1033,1050,127,189],[899,1432,126,189],[1225,1623,112,189],[678,1050,224,141],[1458,0,204,189],[0,0,220,189],[1146,573,189,189],[258,1384,127,189],[1256,1241,126,189],[1255,1432,112,189],[1280,764,224,141],[0,191,204,189],[970,382,189,189],[1648,191,192,189],[484,1193,127,189],[1904,1623,111,189],[1896,1241,126,189],[1825,1432,112,189],[602,907,224,141],[618,191,204,189],[1734,382,189,189],[1664,0,192,189],[1291,1050,127,189],[1150,1814,111,189],[257,1575,126,189],[356,1766,112,189],[1506,907,224,141],[1046,0,204,189],[573,573,189,189],[388,382,192,189],[1713,573,186,189],[1678,1050,127,189],[1489,1814,111,189],[385,1575,126,189],[584,1766,112,189],[1732,907,224,141],[1030,191,204,189],[764,573,189,189],[582,382,192,189],[0,764,186,189],[1807,1050,127,189],[1602,1814,111,189],[513,1575,126,189],[883,1623,112,189],[226,1050,224,141],[1236,191,204,189],[955,573,189,189],[776,382,192,189],[188,764,186,189],[871,1241,127,189],[1715,1814,111,189],[771,1432,126,189],[769,1623,112,189],[1054,907,224,141],[634,0,204,189],[0,573,189,189],[0,382,192,189],[1858,0,186,189],[1420,1050,127,189],[1263,1814,111,189],[129,1575,126,189],[128,1766,112,189],[828,907,224,141],[824,191,204,189],[191,573,189,189],[1842,191,192,189],[1337,573,186,189],[242,1766,112,189],[1549,1050,127,189],[1376,1814,111,189],[0,1623,126,189],[0,1814,112,189],[1280,907,224,141],[840,0,204,189],[382,573,189,189],[194,382,192,189],[1525,573,186,189],[470,1766,112,189]]},
		{name:"dfs_atlas_18", frames: [[327,0,99,189],[859,382,95,189],[194,1095,92,189],[202,382,217,85],[226,0,99,189],[876,573,95,189],[288,1095,92,189],[421,382,217,85],[529,0,99,189],[438,817,95,189],[870,1146,92,189],[640,382,217,85],[238,1675,40,70],[428,0,99,189],[876,764,95,189],[776,1146,92,189],[202,469,217,85],[48,1668,40,70],[630,0,99,189],[679,1008,95,189],[564,1390,92,189],[657,730,217,85],[616,1752,40,70],[909,191,99,189],[0,1095,95,189],[658,1390,92,189],[0,817,217,85],[658,1752,40,70],[832,0,99,189],[632,817,95,189],[570,1199,92,189],[640,469,217,85],[406,1680,40,70],[946,1436,69,97],[0,191,99,189],[729,817,95,189],[476,1199,92,189],[640,556,217,85],[532,1680,40,70],[752,1528,69,97],[973,782,46,78],[202,191,99,189],[97,904,95,189],[0,1286,92,189],[421,556,217,85],[490,1680,40,70],[251,1477,69,97],[973,622,46,78],[101,191,99,189],[0,904,95,189],[664,1199,92,189],[202,556,217,85],[448,1680,40,70],[180,1477,69,97],[973,702,46,78],[973,542,46,78],[113,0,111,189],[101,382,99,189],[97,1095,95,189],[0,1477,92,189],[219,817,217,85],[174,1755,40,70],[733,1627,69,97],[142,1675,46,78],[190,1675,46,78],[132,1755,40,70],[0,0,111,189],[0,382,99,189],[535,817,95,189],[382,1199,92,189],[421,469,217,85],[364,1680,40,70],[946,1337,69,97],[956,382,46,78],[956,462,46,78],[280,1680,40,70],[322,1680,40,70],[731,0,99,189],[194,904,95,189],[94,1286,92,189],[0,643,217,85],[616,1680,40,70],[823,1528,69,97],[826,817,46,78],[973,862,46,78],[658,1680,40,70],[574,1680,40,70],[606,191,99,189],[388,1008,95,189],[852,1337,92,189],[0,730,217,85],[90,1743,40,70],[449,1581,69,97],[804,1627,46,78],[965,1615,46,78],[280,1752,40,70],[322,1752,40,70],[152,573,36,56],[707,191,99,189],[485,1008,95,189],[376,1390,92,189],[219,730,217,85],[448,1752,40,70],[520,1581,69,97],[852,1634,46,78],[900,1634,46,78],[364,1752,40,70],[406,1752,40,70],[114,573,36,56],[808,191,99,189],[582,1008,95,189],[470,1390,92,189],[438,730,217,85],[574,1752,40,70],[591,1581,69,97],[0,1668,46,78],[94,1663,46,78],[490,1752,40,70],[532,1752,40,70],[826,897,36,56],[662,1581,69,97],[303,191,99,189],[826,955,95,189],[282,1286,92,189],[219,643,217,85],[948,1695,40,70],[94,1564,69,97],[388,904,46,78],[776,1008,46,78],[804,1707,40,70],[846,1714,40,70],[0,573,36,56],[894,1535,69,97],[933,0,84,85],[404,191,99,189],[291,904,95,189],[188,1286,92,189],[438,643,217,85],[888,1714,40,70],[165,1576,69,97],[964,1146,46,78],[964,1226,46,78],[700,1726,40,70],[742,1726,40,70],[38,573,36,56],[236,1576,69,97],[933,87,84,85],[505,191,99,189],[923,955,95,189],[758,1337,92,189],[657,643,217,85],[48,1740,40,70],[307,1581,69,97],[322,1477,46,78],[965,1535,46,78],[238,1747,40,70],[0,1748,40,70],[76,573,36,56],[378,1581,69,97],[94,1477,84,85],[776,1088,35,52]]}
];


// symbols:



(lib.CachedTexturedBitmap_278 = function() {
	this.initialize(ss["dfs_atlas_13"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_279 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_280 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_281 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_282 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_283 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_284 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_285 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_286 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_287 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_288 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_289 = function() {
	this.initialize(ss["dfs_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_292 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_293 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_294 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_295 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_296 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_297 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_298 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_299 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_300 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_301 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_304 = function() {
	this.initialize(ss["dfs_atlas_12"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_305 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_306 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_307 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_308 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_309 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_310 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_311 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_312 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_313 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_314 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_315 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_316 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_317 = function() {
	this.initialize(ss["dfs_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_320 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_321 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_322 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_323 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_324 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_325 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_326 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_327 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_328 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_329 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_330 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_331 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_334 = function() {
	this.initialize(ss["dfs_atlas_13"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_335 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_336 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_337 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_338 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_339 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_340 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_341 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_342 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_343 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_344 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_345 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_346 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_347 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_348 = function() {
	this.initialize(ss["dfs_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_351 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_352 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_353 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_354 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_355 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_356 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_357 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_358 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_359 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_360 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_361 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_362 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_363 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_364 = function() {
	this.initialize(ss["dfs_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_367 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_368 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_369 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_370 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_371 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_372 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_373 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_374 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_375 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_376 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_377 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_378 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_379 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_380 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_381 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_384 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_385 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_386 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_387 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_388 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_389 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_390 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_391 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_392 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_393 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_394 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_395 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_396 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_397 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_398 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_399 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_400 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_401 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_402 = function() {
	this.initialize(ss["dfs_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_405 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_406 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_407 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_408 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_409 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_410 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_411 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_412 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_413 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_414 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_415 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_416 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_417 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_418 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_419 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_420 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_421 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_422 = function() {
	this.initialize(ss["dfs_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_425 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_426 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_427 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_428 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_429 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_430 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_431 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_432 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_433 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_434 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_435 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_436 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_437 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_438 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_439 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_440 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_441 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_442 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_443 = function() {
	this.initialize(ss["dfs_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_446 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_447 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_448 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_449 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_450 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_451 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_452 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_453 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_454 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_455 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_456 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_457 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_458 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_459 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_460 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_461 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_462 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_463 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_464 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_467 = function() {
	this.initialize(ss["dfs_atlas_14"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_468 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_469 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_470 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_471 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_472 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_473 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_474 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_475 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_476 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_477 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_478 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_479 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_480 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_481 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_482 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_483 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_484 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_485 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_486 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_487 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_488 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_489 = function() {
	this.initialize(ss["dfs_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_492 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_493 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_494 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_495 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_496 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_497 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_498 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_499 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_500 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_501 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_502 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_503 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_504 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_505 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_506 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_507 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_508 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_509 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_510 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_511 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_512 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_515 = function() {
	this.initialize(ss["dfs_atlas_14"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_516 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_517 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_518 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_519 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_520 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_521 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_522 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_523 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_524 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_525 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_526 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_527 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_528 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_529 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_530 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_531 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_532 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_533 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_534 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_535 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_536 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_537 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_538 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_539 = function() {
	this.initialize(ss["dfs_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_542 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_543 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_544 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_545 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_546 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_547 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_548 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_549 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_550 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_551 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_552 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_553 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_554 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_555 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_556 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_557 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_558 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_559 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_560 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_561 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_562 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_563 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_564 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_565 = function() {
	this.initialize(ss["dfs_atlas_12"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_568 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_569 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_570 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_571 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_572 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_573 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_574 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_575 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_576 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_577 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_578 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_579 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_580 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_581 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_582 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_583 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_584 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_585 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_586 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_587 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_588 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_589 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_590 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_591 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_594 = function() {
	this.initialize(ss["dfs_atlas_15"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_595 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_596 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_597 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_598 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_599 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_600 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_601 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_602 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_603 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_604 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_605 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_606 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_607 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_608 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_609 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_610 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_611 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_612 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_613 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_614 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_615 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_616 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_617 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_618 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_619 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_620 = function() {
	this.initialize(ss["dfs_atlas_11"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_623 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_624 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_625 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_626 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_627 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_628 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_629 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_630 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_631 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_632 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_633 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_634 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_635 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_636 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_637 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_638 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_639 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_640 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_641 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_642 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_643 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_644 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_645 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_646 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_647 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_648 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_649 = function() {
	this.initialize(ss["dfs_atlas_10"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_650 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_651 = function() {
	this.initialize(ss["dfs_atlas_15"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_652 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_653 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_654 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_655 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_656 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_657 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_658 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_659 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_660 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_661 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_662 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_663 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_664 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_665 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_666 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_667 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_668 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_669 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_670 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_671 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_672 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_673 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_674 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_675 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_676 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_677 = function() {
	this.initialize(ss["dfs_atlas_17"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_678 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_679 = function() {
	this.initialize(ss["dfs_atlas_16"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_680 = function() {
	this.initialize(ss["dfs_atlas_18"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_680();
	this.instance.parent = this;
	this.instance.setTransform(64.65,0,0.6731,0.6731);

	this.instance_1 = new lib.CachedTexturedBitmap_679();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-1.2,10.25,0.6731,0.6731);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,0,191.79999999999998,114.6);


// stage content:
(lib.dfs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_104 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(104).call(this.frame_104).wait(1));

	// Tree
	this.instance = new lib.CachedTexturedBitmap_288();
	this.instance.parent = this;
	this.instance.setTransform(63.35,525.9,0.5,0.5);

	this.instance_1 = new lib.CachedTexturedBitmap_287();
	this.instance_1.parent = this;
	this.instance_1.setTransform(777.45,111.95,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_286();
	this.instance_2.parent = this;
	this.instance_2.setTransform(775.85,30.25,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_285();
	this.instance_3.parent = this;
	this.instance_3.setTransform(729.85,356.35,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_284();
	this.instance_4.parent = this;
	this.instance_4.setTransform(540.05,356.35,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_283();
	this.instance_5.parent = this;
	this.instance_5.setTransform(344.45,356.35,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_282();
	this.instance_6.parent = this;
	this.instance_6.setTransform(140.55,356.35,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_281();
	this.instance_7.parent = this;
	this.instance_7.setTransform(634.7,215.7,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_280();
	this.instance_8.parent = this;
	this.instance_8.setTransform(241.45,217.25,0.5,0.5);

	this.instance_9 = new lib.CachedTexturedBitmap_279();
	this.instance_9.parent = this;
	this.instance_9.setTransform(434.5,88.2,0.5,0.5);

	this.instance_10 = new lib.CachedTexturedBitmap_278();
	this.instance_10.parent = this;
	this.instance_10.setTransform(122.7,84.35,0.5,0.5);

	this.instance_11 = new lib.CachedTexturedBitmap_650();
	this.instance_11.parent = this;
	this.instance_11.setTransform(164.75,136.55,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_289();
	this.instance_12.parent = this;
	this.instance_12.setTransform(45.65,15.65,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_301();
	this.instance_13.parent = this;
	this.instance_13.setTransform(63.35,525.9,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_300();
	this.instance_14.parent = this;
	this.instance_14.setTransform(777.45,111.95,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_299();
	this.instance_15.parent = this;
	this.instance_15.setTransform(775.85,30.25,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_298();
	this.instance_16.parent = this;
	this.instance_16.setTransform(729.85,356.35,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_297();
	this.instance_17.parent = this;
	this.instance_17.setTransform(540.05,356.35,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_296();
	this.instance_18.parent = this;
	this.instance_18.setTransform(344.45,356.35,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_295();
	this.instance_19.parent = this;
	this.instance_19.setTransform(140.55,356.35,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_294();
	this.instance_20.parent = this;
	this.instance_20.setTransform(634.7,215.7,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_293();
	this.instance_21.parent = this;
	this.instance_21.setTransform(241.45,217.25,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_292();
	this.instance_22.parent = this;
	this.instance_22.setTransform(434.5,88.2,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_304();
	this.instance_23.parent = this;
	this.instance_23.setTransform(122.7,84.35,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_316();
	this.instance_24.parent = this;
	this.instance_24.setTransform(297.5,94.3,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_315();
	this.instance_25.parent = this;
	this.instance_25.setTransform(178.3,502.7,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_314();
	this.instance_26.parent = this;
	this.instance_26.setTransform(63.35,525.9,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_313();
	this.instance_27.parent = this;
	this.instance_27.setTransform(777.45,111.95,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_312();
	this.instance_28.parent = this;
	this.instance_28.setTransform(775.85,30.25,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_311();
	this.instance_29.parent = this;
	this.instance_29.setTransform(729.85,356.35,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_310();
	this.instance_30.parent = this;
	this.instance_30.setTransform(540.05,356.35,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_309();
	this.instance_31.parent = this;
	this.instance_31.setTransform(344.45,356.35,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_308();
	this.instance_32.parent = this;
	this.instance_32.setTransform(140.55,356.35,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_307();
	this.instance_33.parent = this;
	this.instance_33.setTransform(634.7,215.7,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_306();
	this.instance_34.parent = this;
	this.instance_34.setTransform(241.45,217.25,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_305();
	this.instance_35.parent = this;
	this.instance_35.setTransform(434.5,88.2,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_317();
	this.instance_36.parent = this;
	this.instance_36.setTransform(45.65,15.65,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_331();
	this.instance_37.parent = this;
	this.instance_37.setTransform(297.5,94.3,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_330();
	this.instance_38.parent = this;
	this.instance_38.setTransform(178.3,502.7,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_329();
	this.instance_39.parent = this;
	this.instance_39.setTransform(63.35,525.9,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_328();
	this.instance_40.parent = this;
	this.instance_40.setTransform(777.45,111.95,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_327();
	this.instance_41.parent = this;
	this.instance_41.setTransform(775.85,30.25,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_326();
	this.instance_42.parent = this;
	this.instance_42.setTransform(729.85,356.35,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_325();
	this.instance_43.parent = this;
	this.instance_43.setTransform(540.05,356.35,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_324();
	this.instance_44.parent = this;
	this.instance_44.setTransform(344.45,356.35,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_323();
	this.instance_45.parent = this;
	this.instance_45.setTransform(140.55,356.35,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_322();
	this.instance_46.parent = this;
	this.instance_46.setTransform(634.7,215.7,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_321();
	this.instance_47.parent = this;
	this.instance_47.setTransform(241.45,217.25,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_320();
	this.instance_48.parent = this;
	this.instance_48.setTransform(434.5,88.2,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_334();
	this.instance_49.parent = this;
	this.instance_49.setTransform(122.7,84.35,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_347();
	this.instance_50.parent = this;
	this.instance_50.setTransform(300.25,503.95,0.5,0.5);

	this.instance_51 = new lib.Symbol3();
	this.instance_51.parent = this;
	this.instance_51.setTransform(163.6,305.8,0.4996,0.7429,-14.9985,0,0,94.7,57.4);
	new cjs.ButtonHelper(this.instance_51, 0, 1, 1);

	this.instance_52 = new lib.CachedTexturedBitmap_346();
	this.instance_52.parent = this;
	this.instance_52.setTransform(297.5,94.3,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_345();
	this.instance_53.parent = this;
	this.instance_53.setTransform(178.3,502.7,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_344();
	this.instance_54.parent = this;
	this.instance_54.setTransform(63.35,525.9,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_343();
	this.instance_55.parent = this;
	this.instance_55.setTransform(777.45,111.95,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_342();
	this.instance_56.parent = this;
	this.instance_56.setTransform(775.85,30.25,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_341();
	this.instance_57.parent = this;
	this.instance_57.setTransform(729.85,356.35,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_340();
	this.instance_58.parent = this;
	this.instance_58.setTransform(540.05,356.35,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_339();
	this.instance_59.parent = this;
	this.instance_59.setTransform(344.45,356.35,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_338();
	this.instance_60.parent = this;
	this.instance_60.setTransform(140.55,356.35,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_337();
	this.instance_61.parent = this;
	this.instance_61.setTransform(634.7,215.7,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_336();
	this.instance_62.parent = this;
	this.instance_62.setTransform(241.45,217.25,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_335();
	this.instance_63.parent = this;
	this.instance_63.setTransform(434.5,88.2,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_348();
	this.instance_64.parent = this;
	this.instance_64.setTransform(45.65,15.65,0.5,0.5);

	this.instance_65 = new lib.CachedTexturedBitmap_363();
	this.instance_65.parent = this;
	this.instance_65.setTransform(300.25,503.95,0.5,0.5);

	this.instance_66 = new lib.CachedTexturedBitmap_362();
	this.instance_66.parent = this;
	this.instance_66.setTransform(297.5,94.3,0.5,0.5);

	this.instance_67 = new lib.CachedTexturedBitmap_361();
	this.instance_67.parent = this;
	this.instance_67.setTransform(178.3,502.7,0.5,0.5);

	this.instance_68 = new lib.CachedTexturedBitmap_360();
	this.instance_68.parent = this;
	this.instance_68.setTransform(63.35,525.9,0.5,0.5);

	this.instance_69 = new lib.CachedTexturedBitmap_359();
	this.instance_69.parent = this;
	this.instance_69.setTransform(777.45,111.95,0.5,0.5);

	this.instance_70 = new lib.CachedTexturedBitmap_358();
	this.instance_70.parent = this;
	this.instance_70.setTransform(775.85,30.25,0.5,0.5);

	this.instance_71 = new lib.CachedTexturedBitmap_357();
	this.instance_71.parent = this;
	this.instance_71.setTransform(729.85,356.35,0.5,0.5);

	this.instance_72 = new lib.CachedTexturedBitmap_356();
	this.instance_72.parent = this;
	this.instance_72.setTransform(540.05,356.35,0.5,0.5);

	this.instance_73 = new lib.CachedTexturedBitmap_355();
	this.instance_73.parent = this;
	this.instance_73.setTransform(344.45,356.35,0.5,0.5);

	this.instance_74 = new lib.CachedTexturedBitmap_354();
	this.instance_74.parent = this;
	this.instance_74.setTransform(140.55,356.35,0.5,0.5);

	this.instance_75 = new lib.CachedTexturedBitmap_353();
	this.instance_75.parent = this;
	this.instance_75.setTransform(634.7,215.7,0.5,0.5);

	this.instance_76 = new lib.CachedTexturedBitmap_352();
	this.instance_76.parent = this;
	this.instance_76.setTransform(241.45,217.25,0.5,0.5);

	this.instance_77 = new lib.CachedTexturedBitmap_351();
	this.instance_77.parent = this;
	this.instance_77.setTransform(434.5,88.2,0.5,0.5);

	this.instance_78 = new lib.CachedTexturedBitmap_384();
	this.instance_78.parent = this;
	this.instance_78.setTransform(122.7,84.35,0.5,0.5);

	this.instance_79 = new lib.CachedTexturedBitmap_381();
	this.instance_79.parent = this;
	this.instance_79.setTransform(219.95,358.2,0.5,0.5);

	this.instance_80 = new lib.CachedTexturedBitmap_380();
	this.instance_80.parent = this;
	this.instance_80.setTransform(413.1,503.95,0.5,0.5);

	this.instance_81 = new lib.CachedTexturedBitmap_379();
	this.instance_81.parent = this;
	this.instance_81.setTransform(300.25,503.95,0.5,0.5);

	this.instance_82 = new lib.CachedTexturedBitmap_378();
	this.instance_82.parent = this;
	this.instance_82.setTransform(297.5,94.3,0.5,0.5);

	this.instance_83 = new lib.CachedTexturedBitmap_377();
	this.instance_83.parent = this;
	this.instance_83.setTransform(178.3,502.7,0.5,0.5);

	this.instance_84 = new lib.CachedTexturedBitmap_376();
	this.instance_84.parent = this;
	this.instance_84.setTransform(63.35,525.9,0.5,0.5);

	this.instance_85 = new lib.CachedTexturedBitmap_375();
	this.instance_85.parent = this;
	this.instance_85.setTransform(777.45,111.95,0.5,0.5);

	this.instance_86 = new lib.CachedTexturedBitmap_374();
	this.instance_86.parent = this;
	this.instance_86.setTransform(775.85,30.25,0.5,0.5);

	this.instance_87 = new lib.CachedTexturedBitmap_373();
	this.instance_87.parent = this;
	this.instance_87.setTransform(729.85,356.35,0.5,0.5);

	this.instance_88 = new lib.CachedTexturedBitmap_372();
	this.instance_88.parent = this;
	this.instance_88.setTransform(540.05,356.35,0.5,0.5);

	this.instance_89 = new lib.CachedTexturedBitmap_371();
	this.instance_89.parent = this;
	this.instance_89.setTransform(344.45,356.35,0.5,0.5);

	this.instance_90 = new lib.CachedTexturedBitmap_370();
	this.instance_90.parent = this;
	this.instance_90.setTransform(140.55,356.35,0.5,0.5);

	this.instance_91 = new lib.CachedTexturedBitmap_369();
	this.instance_91.parent = this;
	this.instance_91.setTransform(634.7,215.7,0.5,0.5);

	this.instance_92 = new lib.CachedTexturedBitmap_368();
	this.instance_92.parent = this;
	this.instance_92.setTransform(241.45,217.25,0.5,0.5);

	this.instance_93 = new lib.CachedTexturedBitmap_367();
	this.instance_93.parent = this;
	this.instance_93.setTransform(434.5,88.2,0.5,0.5);

	this.instance_94 = new lib.CachedTexturedBitmap_364();
	this.instance_94.parent = this;
	this.instance_94.setTransform(45.65,15.65,0.5,0.5);

	this.instance_95 = new lib.CachedTexturedBitmap_401();
	this.instance_95.parent = this;
	this.instance_95.setTransform(284.35,339.35,0.5,0.5);

	this.instance_96 = new lib.CachedTexturedBitmap_400();
	this.instance_96.parent = this;
	this.instance_96.setTransform(530.65,502.7,0.5,0.5);

	this.instance_97 = new lib.CachedTexturedBitmap_399();
	this.instance_97.parent = this;
	this.instance_97.setTransform(219.95,358.2,0.5,0.5);

	this.instance_98 = new lib.CachedTexturedBitmap_398();
	this.instance_98.parent = this;
	this.instance_98.setTransform(413.1,503.95,0.5,0.5);

	this.instance_99 = new lib.CachedTexturedBitmap_397();
	this.instance_99.parent = this;
	this.instance_99.setTransform(300.25,503.95,0.5,0.5);

	this.instance_100 = new lib.CachedTexturedBitmap_396();
	this.instance_100.parent = this;
	this.instance_100.setTransform(297.5,94.3,0.5,0.5);

	this.instance_101 = new lib.CachedTexturedBitmap_395();
	this.instance_101.parent = this;
	this.instance_101.setTransform(178.3,502.7,0.5,0.5);

	this.instance_102 = new lib.CachedTexturedBitmap_394();
	this.instance_102.parent = this;
	this.instance_102.setTransform(63.35,525.9,0.5,0.5);

	this.instance_103 = new lib.CachedTexturedBitmap_393();
	this.instance_103.parent = this;
	this.instance_103.setTransform(777.45,111.95,0.5,0.5);

	this.instance_104 = new lib.CachedTexturedBitmap_392();
	this.instance_104.parent = this;
	this.instance_104.setTransform(775.85,30.25,0.5,0.5);

	this.instance_105 = new lib.CachedTexturedBitmap_391();
	this.instance_105.parent = this;
	this.instance_105.setTransform(729.85,356.35,0.5,0.5);

	this.instance_106 = new lib.CachedTexturedBitmap_390();
	this.instance_106.parent = this;
	this.instance_106.setTransform(540.05,356.35,0.5,0.5);

	this.instance_107 = new lib.CachedTexturedBitmap_389();
	this.instance_107.parent = this;
	this.instance_107.setTransform(344.45,356.35,0.5,0.5);

	this.instance_108 = new lib.CachedTexturedBitmap_388();
	this.instance_108.parent = this;
	this.instance_108.setTransform(140.55,356.35,0.5,0.5);

	this.instance_109 = new lib.CachedTexturedBitmap_387();
	this.instance_109.parent = this;
	this.instance_109.setTransform(634.7,215.7,0.5,0.5);

	this.instance_110 = new lib.CachedTexturedBitmap_386();
	this.instance_110.parent = this;
	this.instance_110.setTransform(241.45,217.25,0.5,0.5);

	this.instance_111 = new lib.CachedTexturedBitmap_385();
	this.instance_111.parent = this;
	this.instance_111.setTransform(434.5,88.2,0.5,0.5);

	this.instance_112 = new lib.CachedTexturedBitmap_402();
	this.instance_112.parent = this;
	this.instance_112.setTransform(45.65,15.65,0.5,0.5);

	this.instance_113 = new lib.CachedTexturedBitmap_421();
	this.instance_113.parent = this;
	this.instance_113.setTransform(284.35,339.35,0.5,0.5);

	this.instance_114 = new lib.CachedTexturedBitmap_420();
	this.instance_114.parent = this;
	this.instance_114.setTransform(530.65,502.7,0.5,0.5);

	this.instance_115 = new lib.CachedTexturedBitmap_419();
	this.instance_115.parent = this;
	this.instance_115.setTransform(219.95,358.2,0.5,0.5);

	this.instance_116 = new lib.CachedTexturedBitmap_418();
	this.instance_116.parent = this;
	this.instance_116.setTransform(413.1,503.95,0.5,0.5);

	this.instance_117 = new lib.CachedTexturedBitmap_417();
	this.instance_117.parent = this;
	this.instance_117.setTransform(300.25,503.95,0.5,0.5);

	this.instance_118 = new lib.CachedTexturedBitmap_416();
	this.instance_118.parent = this;
	this.instance_118.setTransform(297.5,94.3,0.5,0.5);

	this.instance_119 = new lib.CachedTexturedBitmap_415();
	this.instance_119.parent = this;
	this.instance_119.setTransform(178.3,502.7,0.5,0.5);

	this.instance_120 = new lib.CachedTexturedBitmap_414();
	this.instance_120.parent = this;
	this.instance_120.setTransform(63.35,525.9,0.5,0.5);

	this.instance_121 = new lib.CachedTexturedBitmap_413();
	this.instance_121.parent = this;
	this.instance_121.setTransform(777.45,111.95,0.5,0.5);

	this.instance_122 = new lib.CachedTexturedBitmap_412();
	this.instance_122.parent = this;
	this.instance_122.setTransform(775.85,30.25,0.5,0.5);

	this.instance_123 = new lib.CachedTexturedBitmap_411();
	this.instance_123.parent = this;
	this.instance_123.setTransform(729.85,356.35,0.5,0.5);

	this.instance_124 = new lib.CachedTexturedBitmap_410();
	this.instance_124.parent = this;
	this.instance_124.setTransform(540.05,356.35,0.5,0.5);

	this.instance_125 = new lib.CachedTexturedBitmap_409();
	this.instance_125.parent = this;
	this.instance_125.setTransform(344.45,356.35,0.5,0.5);

	this.instance_126 = new lib.CachedTexturedBitmap_408();
	this.instance_126.parent = this;
	this.instance_126.setTransform(140.55,356.35,0.5,0.5);

	this.instance_127 = new lib.CachedTexturedBitmap_407();
	this.instance_127.parent = this;
	this.instance_127.setTransform(634.7,215.7,0.5,0.5);

	this.instance_128 = new lib.CachedTexturedBitmap_406();
	this.instance_128.parent = this;
	this.instance_128.setTransform(241.45,217.25,0.5,0.5);

	this.instance_129 = new lib.CachedTexturedBitmap_405();
	this.instance_129.parent = this;
	this.instance_129.setTransform(434.5,88.2,0.5,0.5);

	this.instance_130 = new lib.CachedTexturedBitmap_467();
	this.instance_130.parent = this;
	this.instance_130.setTransform(122.7,84.35,0.5,0.5);

	this.instance_131 = new lib.CachedTexturedBitmap_442();
	this.instance_131.parent = this;
	this.instance_131.setTransform(354.75,293.2,0.5,0.5);

	this.instance_132 = new lib.CachedTexturedBitmap_441();
	this.instance_132.parent = this;
	this.instance_132.setTransform(284.35,339.35,0.5,0.5);

	this.instance_133 = new lib.CachedTexturedBitmap_440();
	this.instance_133.parent = this;
	this.instance_133.setTransform(530.65,502.7,0.5,0.5);

	this.instance_134 = new lib.CachedTexturedBitmap_439();
	this.instance_134.parent = this;
	this.instance_134.setTransform(219.95,358.2,0.5,0.5);

	this.instance_135 = new lib.CachedTexturedBitmap_438();
	this.instance_135.parent = this;
	this.instance_135.setTransform(413.1,503.95,0.5,0.5);

	this.instance_136 = new lib.CachedTexturedBitmap_437();
	this.instance_136.parent = this;
	this.instance_136.setTransform(300.25,503.95,0.5,0.5);

	this.instance_137 = new lib.CachedTexturedBitmap_436();
	this.instance_137.parent = this;
	this.instance_137.setTransform(297.5,94.3,0.5,0.5);

	this.instance_138 = new lib.CachedTexturedBitmap_435();
	this.instance_138.parent = this;
	this.instance_138.setTransform(178.3,502.7,0.5,0.5);

	this.instance_139 = new lib.CachedTexturedBitmap_434();
	this.instance_139.parent = this;
	this.instance_139.setTransform(63.35,525.9,0.5,0.5);

	this.instance_140 = new lib.CachedTexturedBitmap_433();
	this.instance_140.parent = this;
	this.instance_140.setTransform(777.45,111.95,0.5,0.5);

	this.instance_141 = new lib.CachedTexturedBitmap_432();
	this.instance_141.parent = this;
	this.instance_141.setTransform(775.85,30.25,0.5,0.5);

	this.instance_142 = new lib.CachedTexturedBitmap_431();
	this.instance_142.parent = this;
	this.instance_142.setTransform(729.85,356.35,0.5,0.5);

	this.instance_143 = new lib.CachedTexturedBitmap_430();
	this.instance_143.parent = this;
	this.instance_143.setTransform(540.05,356.35,0.5,0.5);

	this.instance_144 = new lib.CachedTexturedBitmap_429();
	this.instance_144.parent = this;
	this.instance_144.setTransform(344.45,356.35,0.5,0.5);

	this.instance_145 = new lib.CachedTexturedBitmap_428();
	this.instance_145.parent = this;
	this.instance_145.setTransform(140.55,356.35,0.5,0.5);

	this.instance_146 = new lib.CachedTexturedBitmap_427();
	this.instance_146.parent = this;
	this.instance_146.setTransform(634.7,215.7,0.5,0.5);

	this.instance_147 = new lib.CachedTexturedBitmap_426();
	this.instance_147.parent = this;
	this.instance_147.setTransform(241.45,217.25,0.5,0.5);

	this.instance_148 = new lib.CachedTexturedBitmap_425();
	this.instance_148.parent = this;
	this.instance_148.setTransform(434.5,88.2,0.5,0.5);

	this.instance_149 = new lib.CachedTexturedBitmap_422();
	this.instance_149.parent = this;
	this.instance_149.setTransform(45.65,15.65,0.5,0.5);

	this.instance_150 = new lib.CachedTexturedBitmap_464();
	this.instance_150.parent = this;
	this.instance_150.setTransform(386.05,232.9,0.5,0.5);

	this.instance_151 = new lib.CachedTexturedBitmap_463();
	this.instance_151.parent = this;
	this.instance_151.setTransform(354.75,293.2,0.5,0.5);

	this.instance_152 = new lib.CachedTexturedBitmap_462();
	this.instance_152.parent = this;
	this.instance_152.setTransform(284.35,339.35,0.5,0.5);

	this.instance_153 = new lib.CachedTexturedBitmap_461();
	this.instance_153.parent = this;
	this.instance_153.setTransform(530.65,502.7,0.5,0.5);

	this.instance_154 = new lib.CachedTexturedBitmap_460();
	this.instance_154.parent = this;
	this.instance_154.setTransform(219.95,358.2,0.5,0.5);

	this.instance_155 = new lib.CachedTexturedBitmap_459();
	this.instance_155.parent = this;
	this.instance_155.setTransform(413.1,503.95,0.5,0.5);

	this.instance_156 = new lib.CachedTexturedBitmap_458();
	this.instance_156.parent = this;
	this.instance_156.setTransform(300.25,503.95,0.5,0.5);

	this.instance_157 = new lib.CachedTexturedBitmap_457();
	this.instance_157.parent = this;
	this.instance_157.setTransform(297.5,94.3,0.5,0.5);

	this.instance_158 = new lib.CachedTexturedBitmap_456();
	this.instance_158.parent = this;
	this.instance_158.setTransform(178.3,502.7,0.5,0.5);

	this.instance_159 = new lib.CachedTexturedBitmap_455();
	this.instance_159.parent = this;
	this.instance_159.setTransform(63.35,525.9,0.5,0.5);

	this.instance_160 = new lib.CachedTexturedBitmap_454();
	this.instance_160.parent = this;
	this.instance_160.setTransform(777.45,111.95,0.5,0.5);

	this.instance_161 = new lib.CachedTexturedBitmap_453();
	this.instance_161.parent = this;
	this.instance_161.setTransform(775.85,30.25,0.5,0.5);

	this.instance_162 = new lib.CachedTexturedBitmap_452();
	this.instance_162.parent = this;
	this.instance_162.setTransform(729.85,356.35,0.5,0.5);

	this.instance_163 = new lib.CachedTexturedBitmap_451();
	this.instance_163.parent = this;
	this.instance_163.setTransform(540.05,356.35,0.5,0.5);

	this.instance_164 = new lib.CachedTexturedBitmap_450();
	this.instance_164.parent = this;
	this.instance_164.setTransform(344.45,356.35,0.5,0.5);

	this.instance_165 = new lib.CachedTexturedBitmap_449();
	this.instance_165.parent = this;
	this.instance_165.setTransform(140.55,356.35,0.5,0.5);

	this.instance_166 = new lib.CachedTexturedBitmap_448();
	this.instance_166.parent = this;
	this.instance_166.setTransform(634.7,215.7,0.5,0.5);

	this.instance_167 = new lib.CachedTexturedBitmap_447();
	this.instance_167.parent = this;
	this.instance_167.setTransform(241.45,217.25,0.5,0.5);

	this.instance_168 = new lib.CachedTexturedBitmap_446();
	this.instance_168.parent = this;
	this.instance_168.setTransform(434.5,88.2,0.5,0.5);

	this.instance_169 = new lib.CachedTexturedBitmap_443();
	this.instance_169.parent = this;
	this.instance_169.setTransform(45.65,15.65,0.5,0.5);

	this.instance_170 = new lib.CachedTexturedBitmap_488();
	this.instance_170.parent = this;
	this.instance_170.setTransform(634.5,503.95,0.5,0.5);

	this.instance_171 = new lib.CachedTexturedBitmap_487();
	this.instance_171.parent = this;
	this.instance_171.setTransform(594.95,88.1,0.5,0.5);

	this.instance_172 = new lib.CachedTexturedBitmap_486();
	this.instance_172.parent = this;
	this.instance_172.setTransform(386.05,232.9,0.5,0.5);

	this.instance_173 = new lib.CachedTexturedBitmap_485();
	this.instance_173.parent = this;
	this.instance_173.setTransform(354.75,293.2,0.5,0.5);

	this.instance_174 = new lib.CachedTexturedBitmap_484();
	this.instance_174.parent = this;
	this.instance_174.setTransform(284.35,339.35,0.5,0.5);

	this.instance_175 = new lib.CachedTexturedBitmap_483();
	this.instance_175.parent = this;
	this.instance_175.setTransform(531.9,503.95,0.5,0.5);

	this.instance_176 = new lib.CachedTexturedBitmap_482();
	this.instance_176.parent = this;
	this.instance_176.setTransform(219.95,358.2,0.5,0.5);

	this.instance_177 = new lib.CachedTexturedBitmap_481();
	this.instance_177.parent = this;
	this.instance_177.setTransform(413.1,503.95,0.5,0.5);

	this.instance_178 = new lib.CachedTexturedBitmap_480();
	this.instance_178.parent = this;
	this.instance_178.setTransform(300.25,503.95,0.5,0.5);

	this.instance_179 = new lib.CachedTexturedBitmap_479();
	this.instance_179.parent = this;
	this.instance_179.setTransform(297.5,94.3,0.5,0.5);

	this.instance_180 = new lib.CachedTexturedBitmap_478();
	this.instance_180.parent = this;
	this.instance_180.setTransform(178.3,502.7,0.5,0.5);

	this.instance_181 = new lib.CachedTexturedBitmap_477();
	this.instance_181.parent = this;
	this.instance_181.setTransform(63.35,525.9,0.5,0.5);

	this.instance_182 = new lib.CachedTexturedBitmap_476();
	this.instance_182.parent = this;
	this.instance_182.setTransform(777.45,111.95,0.5,0.5);

	this.instance_183 = new lib.CachedTexturedBitmap_475();
	this.instance_183.parent = this;
	this.instance_183.setTransform(775.85,30.25,0.5,0.5);

	this.instance_184 = new lib.CachedTexturedBitmap_474();
	this.instance_184.parent = this;
	this.instance_184.setTransform(729.85,356.35,0.5,0.5);

	this.instance_185 = new lib.CachedTexturedBitmap_473();
	this.instance_185.parent = this;
	this.instance_185.setTransform(540.05,356.35,0.5,0.5);

	this.instance_186 = new lib.CachedTexturedBitmap_472();
	this.instance_186.parent = this;
	this.instance_186.setTransform(344.45,356.35,0.5,0.5);

	this.instance_187 = new lib.CachedTexturedBitmap_471();
	this.instance_187.parent = this;
	this.instance_187.setTransform(140.55,356.35,0.5,0.5);

	this.instance_188 = new lib.CachedTexturedBitmap_470();
	this.instance_188.parent = this;
	this.instance_188.setTransform(634.7,215.7,0.5,0.5);

	this.instance_189 = new lib.CachedTexturedBitmap_469();
	this.instance_189.parent = this;
	this.instance_189.setTransform(241.45,217.25,0.5,0.5);

	this.instance_190 = new lib.CachedTexturedBitmap_468();
	this.instance_190.parent = this;
	this.instance_190.setTransform(434.5,88.2,0.5,0.5);

	this.instance_191 = new lib.CachedTexturedBitmap_489();
	this.instance_191.parent = this;
	this.instance_191.setTransform(45.65,15.65,0.5,0.5);

	this.instance_192 = new lib.CachedTexturedBitmap_512();
	this.instance_192.parent = this;
	this.instance_192.setTransform(634.5,503.95,0.5,0.5);

	this.instance_193 = new lib.CachedTexturedBitmap_511();
	this.instance_193.parent = this;
	this.instance_193.setTransform(531.9,503.95,0.5,0.5);

	this.instance_194 = new lib.CachedTexturedBitmap_510();
	this.instance_194.parent = this;
	this.instance_194.setTransform(594.95,88.1,0.5,0.5);

	this.instance_195 = new lib.CachedTexturedBitmap_509();
	this.instance_195.parent = this;
	this.instance_195.setTransform(386.05,232.9,0.5,0.5);

	this.instance_196 = new lib.CachedTexturedBitmap_508();
	this.instance_196.parent = this;
	this.instance_196.setTransform(354.75,293.2,0.5,0.5);

	this.instance_197 = new lib.CachedTexturedBitmap_507();
	this.instance_197.parent = this;
	this.instance_197.setTransform(284.35,339.35,0.5,0.5);

	this.instance_198 = new lib.CachedTexturedBitmap_506();
	this.instance_198.parent = this;
	this.instance_198.setTransform(219.95,358.2,0.5,0.5);

	this.instance_199 = new lib.CachedTexturedBitmap_505();
	this.instance_199.parent = this;
	this.instance_199.setTransform(413.1,503.95,0.5,0.5);

	this.instance_200 = new lib.CachedTexturedBitmap_504();
	this.instance_200.parent = this;
	this.instance_200.setTransform(300.25,503.95,0.5,0.5);

	this.instance_201 = new lib.CachedTexturedBitmap_503();
	this.instance_201.parent = this;
	this.instance_201.setTransform(297.5,94.3,0.5,0.5);

	this.instance_202 = new lib.CachedTexturedBitmap_502();
	this.instance_202.parent = this;
	this.instance_202.setTransform(178.3,502.7,0.5,0.5);

	this.instance_203 = new lib.CachedTexturedBitmap_501();
	this.instance_203.parent = this;
	this.instance_203.setTransform(63.35,525.9,0.5,0.5);

	this.instance_204 = new lib.CachedTexturedBitmap_500();
	this.instance_204.parent = this;
	this.instance_204.setTransform(777.45,111.95,0.5,0.5);

	this.instance_205 = new lib.CachedTexturedBitmap_499();
	this.instance_205.parent = this;
	this.instance_205.setTransform(775.85,30.25,0.5,0.5);

	this.instance_206 = new lib.CachedTexturedBitmap_498();
	this.instance_206.parent = this;
	this.instance_206.setTransform(729.85,356.35,0.5,0.5);

	this.instance_207 = new lib.CachedTexturedBitmap_497();
	this.instance_207.parent = this;
	this.instance_207.setTransform(540.05,356.35,0.5,0.5);

	this.instance_208 = new lib.CachedTexturedBitmap_496();
	this.instance_208.parent = this;
	this.instance_208.setTransform(344.45,356.35,0.5,0.5);

	this.instance_209 = new lib.CachedTexturedBitmap_495();
	this.instance_209.parent = this;
	this.instance_209.setTransform(140.55,356.35,0.5,0.5);

	this.instance_210 = new lib.CachedTexturedBitmap_494();
	this.instance_210.parent = this;
	this.instance_210.setTransform(634.7,215.7,0.5,0.5);

	this.instance_211 = new lib.CachedTexturedBitmap_493();
	this.instance_211.parent = this;
	this.instance_211.setTransform(241.45,217.25,0.5,0.5);

	this.instance_212 = new lib.CachedTexturedBitmap_492();
	this.instance_212.parent = this;
	this.instance_212.setTransform(434.5,88.2,0.5,0.5);

	this.instance_213 = new lib.CachedTexturedBitmap_515();
	this.instance_213.parent = this;
	this.instance_213.setTransform(122.7,84.35,0.5,0.5);

	this.instance_214 = new lib.CachedTexturedBitmap_538();
	this.instance_214.parent = this;
	this.instance_214.setTransform(741.75,503.95,0.5,0.5);

	this.instance_215 = new lib.CachedTexturedBitmap_537();
	this.instance_215.parent = this;
	this.instance_215.setTransform(541.4,257.75,0.5,0.5);

	this.instance_216 = new lib.CachedTexturedBitmap_536();
	this.instance_216.parent = this;
	this.instance_216.setTransform(634.5,503.95,0.5,0.5);

	this.instance_217 = new lib.CachedTexturedBitmap_535();
	this.instance_217.parent = this;
	this.instance_217.setTransform(531.9,503.95,0.5,0.5);

	this.instance_218 = new lib.CachedTexturedBitmap_534();
	this.instance_218.parent = this;
	this.instance_218.setTransform(594.95,88.1,0.5,0.5);

	this.instance_219 = new lib.CachedTexturedBitmap_533();
	this.instance_219.parent = this;
	this.instance_219.setTransform(386.05,232.9,0.5,0.5);

	this.instance_220 = new lib.CachedTexturedBitmap_532();
	this.instance_220.parent = this;
	this.instance_220.setTransform(354.75,293.2,0.5,0.5);

	this.instance_221 = new lib.CachedTexturedBitmap_531();
	this.instance_221.parent = this;
	this.instance_221.setTransform(284.35,339.35,0.5,0.5);

	this.instance_222 = new lib.CachedTexturedBitmap_530();
	this.instance_222.parent = this;
	this.instance_222.setTransform(219.95,358.2,0.5,0.5);

	this.instance_223 = new lib.CachedTexturedBitmap_529();
	this.instance_223.parent = this;
	this.instance_223.setTransform(413.1,503.95,0.5,0.5);

	this.instance_224 = new lib.CachedTexturedBitmap_528();
	this.instance_224.parent = this;
	this.instance_224.setTransform(300.25,503.95,0.5,0.5);

	this.instance_225 = new lib.CachedTexturedBitmap_527();
	this.instance_225.parent = this;
	this.instance_225.setTransform(297.5,94.3,0.5,0.5);

	this.instance_226 = new lib.CachedTexturedBitmap_526();
	this.instance_226.parent = this;
	this.instance_226.setTransform(178.3,502.7,0.5,0.5);

	this.instance_227 = new lib.CachedTexturedBitmap_525();
	this.instance_227.parent = this;
	this.instance_227.setTransform(63.35,525.9,0.5,0.5);

	this.instance_228 = new lib.CachedTexturedBitmap_524();
	this.instance_228.parent = this;
	this.instance_228.setTransform(777.45,111.95,0.5,0.5);

	this.instance_229 = new lib.CachedTexturedBitmap_523();
	this.instance_229.parent = this;
	this.instance_229.setTransform(775.85,30.25,0.5,0.5);

	this.instance_230 = new lib.CachedTexturedBitmap_522();
	this.instance_230.parent = this;
	this.instance_230.setTransform(729.85,356.35,0.5,0.5);

	this.instance_231 = new lib.CachedTexturedBitmap_521();
	this.instance_231.parent = this;
	this.instance_231.setTransform(540.05,356.35,0.5,0.5);

	this.instance_232 = new lib.CachedTexturedBitmap_520();
	this.instance_232.parent = this;
	this.instance_232.setTransform(344.45,356.35,0.5,0.5);

	this.instance_233 = new lib.CachedTexturedBitmap_519();
	this.instance_233.parent = this;
	this.instance_233.setTransform(140.55,356.35,0.5,0.5);

	this.instance_234 = new lib.CachedTexturedBitmap_518();
	this.instance_234.parent = this;
	this.instance_234.setTransform(634.7,215.7,0.5,0.5);

	this.instance_235 = new lib.CachedTexturedBitmap_517();
	this.instance_235.parent = this;
	this.instance_235.setTransform(241.45,217.25,0.5,0.5);

	this.instance_236 = new lib.CachedTexturedBitmap_516();
	this.instance_236.parent = this;
	this.instance_236.setTransform(434.5,88.2,0.5,0.5);

	this.instance_237 = new lib.CachedTexturedBitmap_539();
	this.instance_237.parent = this;
	this.instance_237.setTransform(45.65,15.65,0.5,0.5);

	this.instance_238 = new lib.CachedTexturedBitmap_564();
	this.instance_238.parent = this;
	this.instance_238.setTransform(741.75,503.95,0.5,0.5);

	this.instance_239 = new lib.CachedTexturedBitmap_563();
	this.instance_239.parent = this;
	this.instance_239.setTransform(541.4,257.75,0.5,0.5);

	this.instance_240 = new lib.CachedTexturedBitmap_562();
	this.instance_240.parent = this;
	this.instance_240.setTransform(634.5,503.95,0.5,0.5);

	this.instance_241 = new lib.CachedTexturedBitmap_561();
	this.instance_241.parent = this;
	this.instance_241.setTransform(531.9,503.95,0.5,0.5);

	this.instance_242 = new lib.CachedTexturedBitmap_560();
	this.instance_242.parent = this;
	this.instance_242.setTransform(594.95,88.1,0.5,0.5);

	this.instance_243 = new lib.CachedTexturedBitmap_559();
	this.instance_243.parent = this;
	this.instance_243.setTransform(386.05,232.9,0.5,0.5);

	this.instance_244 = new lib.CachedTexturedBitmap_558();
	this.instance_244.parent = this;
	this.instance_244.setTransform(354.75,293.2,0.5,0.5);

	this.instance_245 = new lib.CachedTexturedBitmap_557();
	this.instance_245.parent = this;
	this.instance_245.setTransform(284.35,339.35,0.5,0.5);

	this.instance_246 = new lib.CachedTexturedBitmap_556();
	this.instance_246.parent = this;
	this.instance_246.setTransform(219.95,358.2,0.5,0.5);

	this.instance_247 = new lib.CachedTexturedBitmap_555();
	this.instance_247.parent = this;
	this.instance_247.setTransform(413.1,503.95,0.5,0.5);

	this.instance_248 = new lib.CachedTexturedBitmap_554();
	this.instance_248.parent = this;
	this.instance_248.setTransform(300.25,503.95,0.5,0.5);

	this.instance_249 = new lib.CachedTexturedBitmap_553();
	this.instance_249.parent = this;
	this.instance_249.setTransform(297.5,94.3,0.5,0.5);

	this.instance_250 = new lib.CachedTexturedBitmap_552();
	this.instance_250.parent = this;
	this.instance_250.setTransform(178.3,502.7,0.5,0.5);

	this.instance_251 = new lib.CachedTexturedBitmap_551();
	this.instance_251.parent = this;
	this.instance_251.setTransform(63.35,525.9,0.5,0.5);

	this.instance_252 = new lib.CachedTexturedBitmap_550();
	this.instance_252.parent = this;
	this.instance_252.setTransform(777.45,111.95,0.5,0.5);

	this.instance_253 = new lib.CachedTexturedBitmap_549();
	this.instance_253.parent = this;
	this.instance_253.setTransform(775.85,30.25,0.5,0.5);

	this.instance_254 = new lib.CachedTexturedBitmap_548();
	this.instance_254.parent = this;
	this.instance_254.setTransform(729.85,356.35,0.5,0.5);

	this.instance_255 = new lib.CachedTexturedBitmap_547();
	this.instance_255.parent = this;
	this.instance_255.setTransform(540.05,356.35,0.5,0.5);

	this.instance_256 = new lib.CachedTexturedBitmap_546();
	this.instance_256.parent = this;
	this.instance_256.setTransform(344.45,356.35,0.5,0.5);

	this.instance_257 = new lib.CachedTexturedBitmap_545();
	this.instance_257.parent = this;
	this.instance_257.setTransform(140.55,356.35,0.5,0.5);

	this.instance_258 = new lib.CachedTexturedBitmap_544();
	this.instance_258.parent = this;
	this.instance_258.setTransform(634.7,215.7,0.5,0.5);

	this.instance_259 = new lib.CachedTexturedBitmap_543();
	this.instance_259.parent = this;
	this.instance_259.setTransform(241.45,217.25,0.5,0.5);

	this.instance_260 = new lib.CachedTexturedBitmap_542();
	this.instance_260.parent = this;
	this.instance_260.setTransform(434.5,88.2,0.5,0.5);

	this.instance_261 = new lib.CachedTexturedBitmap_594();
	this.instance_261.parent = this;
	this.instance_261.setTransform(122.7,84.35,0.5,0.5);

	this.instance_262 = new lib.CachedTexturedBitmap_591();
	this.instance_262.parent = this;
	this.instance_262.setTransform(614.9,358.85,0.5,0.5);

	this.instance_263 = new lib.CachedTexturedBitmap_590();
	this.instance_263.parent = this;
	this.instance_263.setTransform(741.75,503.95,0.5,0.5);

	this.instance_264 = new lib.CachedTexturedBitmap_589();
	this.instance_264.parent = this;
	this.instance_264.setTransform(541.4,257.75,0.5,0.5);

	this.instance_265 = new lib.CachedTexturedBitmap_588();
	this.instance_265.parent = this;
	this.instance_265.setTransform(634.5,503.95,0.5,0.5);

	this.instance_266 = new lib.CachedTexturedBitmap_587();
	this.instance_266.parent = this;
	this.instance_266.setTransform(531.9,503.95,0.5,0.5);

	this.instance_267 = new lib.CachedTexturedBitmap_586();
	this.instance_267.parent = this;
	this.instance_267.setTransform(594.95,88.1,0.5,0.5);

	this.instance_268 = new lib.CachedTexturedBitmap_585();
	this.instance_268.parent = this;
	this.instance_268.setTransform(386.05,232.9,0.5,0.5);

	this.instance_269 = new lib.CachedTexturedBitmap_584();
	this.instance_269.parent = this;
	this.instance_269.setTransform(354.75,293.2,0.5,0.5);

	this.instance_270 = new lib.CachedTexturedBitmap_583();
	this.instance_270.parent = this;
	this.instance_270.setTransform(284.35,339.35,0.5,0.5);

	this.instance_271 = new lib.CachedTexturedBitmap_582();
	this.instance_271.parent = this;
	this.instance_271.setTransform(219.95,358.2,0.5,0.5);

	this.instance_272 = new lib.CachedTexturedBitmap_581();
	this.instance_272.parent = this;
	this.instance_272.setTransform(413.1,503.95,0.5,0.5);

	this.instance_273 = new lib.CachedTexturedBitmap_580();
	this.instance_273.parent = this;
	this.instance_273.setTransform(300.25,503.95,0.5,0.5);

	this.instance_274 = new lib.CachedTexturedBitmap_579();
	this.instance_274.parent = this;
	this.instance_274.setTransform(297.5,94.3,0.5,0.5);

	this.instance_275 = new lib.CachedTexturedBitmap_578();
	this.instance_275.parent = this;
	this.instance_275.setTransform(178.3,502.7,0.5,0.5);

	this.instance_276 = new lib.CachedTexturedBitmap_577();
	this.instance_276.parent = this;
	this.instance_276.setTransform(63.35,525.9,0.5,0.5);

	this.instance_277 = new lib.CachedTexturedBitmap_576();
	this.instance_277.parent = this;
	this.instance_277.setTransform(777.45,111.95,0.5,0.5);

	this.instance_278 = new lib.CachedTexturedBitmap_575();
	this.instance_278.parent = this;
	this.instance_278.setTransform(775.85,30.25,0.5,0.5);

	this.instance_279 = new lib.CachedTexturedBitmap_574();
	this.instance_279.parent = this;
	this.instance_279.setTransform(729.85,356.35,0.5,0.5);

	this.instance_280 = new lib.CachedTexturedBitmap_573();
	this.instance_280.parent = this;
	this.instance_280.setTransform(540.05,356.35,0.5,0.5);

	this.instance_281 = new lib.CachedTexturedBitmap_572();
	this.instance_281.parent = this;
	this.instance_281.setTransform(344.45,356.35,0.5,0.5);

	this.instance_282 = new lib.CachedTexturedBitmap_571();
	this.instance_282.parent = this;
	this.instance_282.setTransform(140.55,356.35,0.5,0.5);

	this.instance_283 = new lib.CachedTexturedBitmap_570();
	this.instance_283.parent = this;
	this.instance_283.setTransform(634.7,215.7,0.5,0.5);

	this.instance_284 = new lib.CachedTexturedBitmap_569();
	this.instance_284.parent = this;
	this.instance_284.setTransform(241.45,217.25,0.5,0.5);

	this.instance_285 = new lib.CachedTexturedBitmap_568();
	this.instance_285.parent = this;
	this.instance_285.setTransform(434.5,88.2,0.5,0.5);

	this.instance_286 = new lib.CachedTexturedBitmap_565();
	this.instance_286.parent = this;
	this.instance_286.setTransform(45.65,15.85,0.5,0.5);

	this.instance_287 = new lib.CachedTexturedBitmap_619();
	this.instance_287.parent = this;
	this.instance_287.setTransform(665.55,353.6,0.5,0.5);

	this.instance_288 = new lib.CachedTexturedBitmap_618();
	this.instance_288.parent = this;
	this.instance_288.setTransform(614.9,358.85,0.5,0.5);

	this.instance_289 = new lib.CachedTexturedBitmap_617();
	this.instance_289.parent = this;
	this.instance_289.setTransform(741.75,503.95,0.5,0.5);

	this.instance_290 = new lib.CachedTexturedBitmap_616();
	this.instance_290.parent = this;
	this.instance_290.setTransform(541.4,257.75,0.5,0.5);

	this.instance_291 = new lib.CachedTexturedBitmap_615();
	this.instance_291.parent = this;
	this.instance_291.setTransform(634.5,503.95,0.5,0.5);

	this.instance_292 = new lib.CachedTexturedBitmap_614();
	this.instance_292.parent = this;
	this.instance_292.setTransform(531.9,503.95,0.5,0.5);

	this.instance_293 = new lib.CachedTexturedBitmap_613();
	this.instance_293.parent = this;
	this.instance_293.setTransform(594.95,88.1,0.5,0.5);

	this.instance_294 = new lib.CachedTexturedBitmap_612();
	this.instance_294.parent = this;
	this.instance_294.setTransform(386.05,232.9,0.5,0.5);

	this.instance_295 = new lib.CachedTexturedBitmap_611();
	this.instance_295.parent = this;
	this.instance_295.setTransform(354.75,293.2,0.5,0.5);

	this.instance_296 = new lib.CachedTexturedBitmap_610();
	this.instance_296.parent = this;
	this.instance_296.setTransform(284.35,339.35,0.5,0.5);

	this.instance_297 = new lib.CachedTexturedBitmap_609();
	this.instance_297.parent = this;
	this.instance_297.setTransform(219.95,358.2,0.5,0.5);

	this.instance_298 = new lib.CachedTexturedBitmap_608();
	this.instance_298.parent = this;
	this.instance_298.setTransform(413.1,503.95,0.5,0.5);

	this.instance_299 = new lib.CachedTexturedBitmap_607();
	this.instance_299.parent = this;
	this.instance_299.setTransform(300.25,503.95,0.5,0.5);

	this.instance_300 = new lib.CachedTexturedBitmap_606();
	this.instance_300.parent = this;
	this.instance_300.setTransform(297.5,94.3,0.5,0.5);

	this.instance_301 = new lib.CachedTexturedBitmap_605();
	this.instance_301.parent = this;
	this.instance_301.setTransform(178.3,502.7,0.5,0.5);

	this.instance_302 = new lib.CachedTexturedBitmap_604();
	this.instance_302.parent = this;
	this.instance_302.setTransform(63.35,525.9,0.5,0.5);

	this.instance_303 = new lib.CachedTexturedBitmap_603();
	this.instance_303.parent = this;
	this.instance_303.setTransform(777.45,111.95,0.5,0.5);

	this.instance_304 = new lib.CachedTexturedBitmap_602();
	this.instance_304.parent = this;
	this.instance_304.setTransform(775.85,30.25,0.5,0.5);

	this.instance_305 = new lib.CachedTexturedBitmap_601();
	this.instance_305.parent = this;
	this.instance_305.setTransform(729.85,356.35,0.5,0.5);

	this.instance_306 = new lib.CachedTexturedBitmap_600();
	this.instance_306.parent = this;
	this.instance_306.setTransform(540.05,356.35,0.5,0.5);

	this.instance_307 = new lib.CachedTexturedBitmap_599();
	this.instance_307.parent = this;
	this.instance_307.setTransform(344.45,356.35,0.5,0.5);

	this.instance_308 = new lib.CachedTexturedBitmap_598();
	this.instance_308.parent = this;
	this.instance_308.setTransform(140.55,356.35,0.5,0.5);

	this.instance_309 = new lib.CachedTexturedBitmap_597();
	this.instance_309.parent = this;
	this.instance_309.setTransform(634.7,215.7,0.5,0.5);

	this.instance_310 = new lib.CachedTexturedBitmap_596();
	this.instance_310.parent = this;
	this.instance_310.setTransform(241.45,217.25,0.5,0.5);

	this.instance_311 = new lib.CachedTexturedBitmap_595();
	this.instance_311.parent = this;
	this.instance_311.setTransform(434.5,88.2,0.5,0.5);

	this.instance_312 = new lib.CachedTexturedBitmap_620();
	this.instance_312.parent = this;
	this.instance_312.setTransform(45.65,15.85,0.5,0.5);

	this.instance_313 = new lib.CachedTexturedBitmap_648();
	this.instance_313.parent = this;
	this.instance_313.setTransform(841.1,502.7,0.5,0.5);

	this.instance_314 = new lib.CachedTexturedBitmap_647();
	this.instance_314.parent = this;
	this.instance_314.setTransform(665.55,353.6,0.5,0.5);

	this.instance_315 = new lib.CachedTexturedBitmap_646();
	this.instance_315.parent = this;
	this.instance_315.setTransform(614.9,358.85,0.5,0.5);

	this.instance_316 = new lib.CachedTexturedBitmap_645();
	this.instance_316.parent = this;
	this.instance_316.setTransform(741.75,503.95,0.5,0.5);

	this.instance_317 = new lib.CachedTexturedBitmap_644();
	this.instance_317.parent = this;
	this.instance_317.setTransform(541.4,257.75,0.5,0.5);

	this.instance_318 = new lib.CachedTexturedBitmap_643();
	this.instance_318.parent = this;
	this.instance_318.setTransform(634.5,503.95,0.5,0.5);

	this.instance_319 = new lib.CachedTexturedBitmap_642();
	this.instance_319.parent = this;
	this.instance_319.setTransform(531.9,503.95,0.5,0.5);

	this.instance_320 = new lib.CachedTexturedBitmap_641();
	this.instance_320.parent = this;
	this.instance_320.setTransform(594.95,88.1,0.5,0.5);

	this.instance_321 = new lib.CachedTexturedBitmap_640();
	this.instance_321.parent = this;
	this.instance_321.setTransform(386.05,232.9,0.5,0.5);

	this.instance_322 = new lib.CachedTexturedBitmap_639();
	this.instance_322.parent = this;
	this.instance_322.setTransform(354.75,293.2,0.5,0.5);

	this.instance_323 = new lib.CachedTexturedBitmap_638();
	this.instance_323.parent = this;
	this.instance_323.setTransform(284.35,339.35,0.5,0.5);

	this.instance_324 = new lib.CachedTexturedBitmap_637();
	this.instance_324.parent = this;
	this.instance_324.setTransform(219.95,358.2,0.5,0.5);

	this.instance_325 = new lib.CachedTexturedBitmap_636();
	this.instance_325.parent = this;
	this.instance_325.setTransform(413.1,503.95,0.5,0.5);

	this.instance_326 = new lib.CachedTexturedBitmap_635();
	this.instance_326.parent = this;
	this.instance_326.setTransform(300.25,503.95,0.5,0.5);

	this.instance_327 = new lib.CachedTexturedBitmap_634();
	this.instance_327.parent = this;
	this.instance_327.setTransform(297.5,94.3,0.5,0.5);

	this.instance_328 = new lib.CachedTexturedBitmap_633();
	this.instance_328.parent = this;
	this.instance_328.setTransform(178.3,502.7,0.5,0.5);

	this.instance_329 = new lib.CachedTexturedBitmap_632();
	this.instance_329.parent = this;
	this.instance_329.setTransform(63.35,525.9,0.5,0.5);

	this.instance_330 = new lib.CachedTexturedBitmap_631();
	this.instance_330.parent = this;
	this.instance_330.setTransform(777.45,111.95,0.5,0.5);

	this.instance_331 = new lib.CachedTexturedBitmap_630();
	this.instance_331.parent = this;
	this.instance_331.setTransform(775.85,30.25,0.5,0.5);

	this.instance_332 = new lib.CachedTexturedBitmap_629();
	this.instance_332.parent = this;
	this.instance_332.setTransform(729.85,356.35,0.5,0.5);

	this.instance_333 = new lib.CachedTexturedBitmap_628();
	this.instance_333.parent = this;
	this.instance_333.setTransform(540.05,356.35,0.5,0.5);

	this.instance_334 = new lib.CachedTexturedBitmap_627();
	this.instance_334.parent = this;
	this.instance_334.setTransform(344.45,356.35,0.5,0.5);

	this.instance_335 = new lib.CachedTexturedBitmap_626();
	this.instance_335.parent = this;
	this.instance_335.setTransform(140.55,356.35,0.5,0.5);

	this.instance_336 = new lib.CachedTexturedBitmap_625();
	this.instance_336.parent = this;
	this.instance_336.setTransform(634.7,215.7,0.5,0.5);

	this.instance_337 = new lib.CachedTexturedBitmap_624();
	this.instance_337.parent = this;
	this.instance_337.setTransform(241.45,217.25,0.5,0.5);

	this.instance_338 = new lib.CachedTexturedBitmap_623();
	this.instance_338.parent = this;
	this.instance_338.setTransform(434.5,88.2,0.5,0.5);

	this.instance_339 = new lib.CachedTexturedBitmap_651();
	this.instance_339.parent = this;
	this.instance_339.setTransform(122.7,84.35,0.5,0.5);

	this.instance_340 = new lib.CachedTexturedBitmap_678();
	this.instance_340.parent = this;
	this.instance_340.setTransform(764.3,244.9,0.5,0.5);

	this.instance_341 = new lib.CachedTexturedBitmap_677();
	this.instance_341.parent = this;
	this.instance_341.setTransform(841.1,502.7,0.5,0.5);

	this.instance_342 = new lib.CachedTexturedBitmap_676();
	this.instance_342.parent = this;
	this.instance_342.setTransform(665.55,353.6,0.5,0.5);

	this.instance_343 = new lib.CachedTexturedBitmap_675();
	this.instance_343.parent = this;
	this.instance_343.setTransform(614.9,358.85,0.5,0.5);

	this.instance_344 = new lib.CachedTexturedBitmap_674();
	this.instance_344.parent = this;
	this.instance_344.setTransform(741.75,503.95,0.5,0.5);

	this.instance_345 = new lib.CachedTexturedBitmap_673();
	this.instance_345.parent = this;
	this.instance_345.setTransform(541.4,257.75,0.5,0.5);

	this.instance_346 = new lib.CachedTexturedBitmap_672();
	this.instance_346.parent = this;
	this.instance_346.setTransform(634.5,503.95,0.5,0.5);

	this.instance_347 = new lib.CachedTexturedBitmap_671();
	this.instance_347.parent = this;
	this.instance_347.setTransform(531.9,503.95,0.5,0.5);

	this.instance_348 = new lib.CachedTexturedBitmap_670();
	this.instance_348.parent = this;
	this.instance_348.setTransform(594.95,88.1,0.5,0.5);

	this.instance_349 = new lib.CachedTexturedBitmap_669();
	this.instance_349.parent = this;
	this.instance_349.setTransform(386.05,232.9,0.5,0.5);

	this.instance_350 = new lib.CachedTexturedBitmap_668();
	this.instance_350.parent = this;
	this.instance_350.setTransform(354.75,293.2,0.5,0.5);

	this.instance_351 = new lib.CachedTexturedBitmap_667();
	this.instance_351.parent = this;
	this.instance_351.setTransform(284.35,339.35,0.5,0.5);

	this.instance_352 = new lib.CachedTexturedBitmap_666();
	this.instance_352.parent = this;
	this.instance_352.setTransform(219.95,358.2,0.5,0.5);

	this.instance_353 = new lib.CachedTexturedBitmap_665();
	this.instance_353.parent = this;
	this.instance_353.setTransform(413.1,503.95,0.5,0.5);

	this.instance_354 = new lib.CachedTexturedBitmap_664();
	this.instance_354.parent = this;
	this.instance_354.setTransform(300.25,503.95,0.5,0.5);

	this.instance_355 = new lib.CachedTexturedBitmap_663();
	this.instance_355.parent = this;
	this.instance_355.setTransform(297.5,94.3,0.5,0.5);

	this.instance_356 = new lib.CachedTexturedBitmap_662();
	this.instance_356.parent = this;
	this.instance_356.setTransform(178.3,502.7,0.5,0.5);

	this.instance_357 = new lib.CachedTexturedBitmap_661();
	this.instance_357.parent = this;
	this.instance_357.setTransform(63.35,525.9,0.5,0.5);

	this.instance_358 = new lib.CachedTexturedBitmap_660();
	this.instance_358.parent = this;
	this.instance_358.setTransform(777.45,111.95,0.5,0.5);

	this.instance_359 = new lib.CachedTexturedBitmap_659();
	this.instance_359.parent = this;
	this.instance_359.setTransform(775.85,30.25,0.5,0.5);

	this.instance_360 = new lib.CachedTexturedBitmap_658();
	this.instance_360.parent = this;
	this.instance_360.setTransform(729.85,356.35,0.5,0.5);

	this.instance_361 = new lib.CachedTexturedBitmap_657();
	this.instance_361.parent = this;
	this.instance_361.setTransform(540.05,356.35,0.5,0.5);

	this.instance_362 = new lib.CachedTexturedBitmap_656();
	this.instance_362.parent = this;
	this.instance_362.setTransform(344.45,356.35,0.5,0.5);

	this.instance_363 = new lib.CachedTexturedBitmap_655();
	this.instance_363.parent = this;
	this.instance_363.setTransform(140.55,356.35,0.5,0.5);

	this.instance_364 = new lib.CachedTexturedBitmap_654();
	this.instance_364.parent = this;
	this.instance_364.setTransform(634.7,215.7,0.5,0.5);

	this.instance_365 = new lib.CachedTexturedBitmap_653();
	this.instance_365.parent = this;
	this.instance_365.setTransform(241.45,217.25,0.5,0.5);

	this.instance_366 = new lib.CachedTexturedBitmap_652();
	this.instance_366.parent = this;
	this.instance_366.setTransform(434.5,88.2,0.5,0.5);

	this.instance_367 = new lib.CachedTexturedBitmap_649();
	this.instance_367.parent = this;
	this.instance_367.setTransform(45.65,15.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13}]},4).to({state:[{t:this.instance_36},{t:this.instance_11},{t:this.instance_23},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24}]},5).to({state:[{t:this.instance_36},{t:this.instance_11},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37}]},5).to({state:[{t:this.instance_64},{t:this.instance_11},{t:this.instance_49},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50}]},5).to({state:[{t:this.instance_64},{t:this.instance_11},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_51},{t:this.instance_65}]},5).to({state:[{t:this.instance_94},{t:this.instance_11},{t:this.instance_78},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_51},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79}]},5).to({state:[{t:this.instance_112},{t:this.instance_11},{t:this.instance_78},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_51},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95}]},10).to({state:[{t:this.instance_112},{t:this.instance_11},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_51},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113}]},5).to({state:[{t:this.instance_149},{t:this.instance_11},{t:this.instance_130},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.instance_145},{t:this.instance_144},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_51},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131}]},5).to({state:[{t:this.instance_169},{t:this.instance_11},{t:this.instance_130},{t:this.instance_168},{t:this.instance_167},{t:this.instance_166},{t:this.instance_165},{t:this.instance_164},{t:this.instance_163},{t:this.instance_162},{t:this.instance_161},{t:this.instance_160},{t:this.instance_159},{t:this.instance_158},{t:this.instance_157},{t:this.instance_51},{t:this.instance_156},{t:this.instance_155},{t:this.instance_154},{t:this.instance_153},{t:this.instance_152},{t:this.instance_151},{t:this.instance_150}]},10).to({state:[{t:this.instance_191},{t:this.instance_11},{t:this.instance_130},{t:this.instance_190},{t:this.instance_189},{t:this.instance_188},{t:this.instance_187},{t:this.instance_186},{t:this.instance_185},{t:this.instance_184},{t:this.instance_183},{t:this.instance_182},{t:this.instance_181},{t:this.instance_180},{t:this.instance_179},{t:this.instance_51},{t:this.instance_178},{t:this.instance_177},{t:this.instance_176},{t:this.instance_175},{t:this.instance_174},{t:this.instance_173},{t:this.instance_172},{t:this.instance_171},{t:this.instance_170}]},10).to({state:[{t:this.instance_191},{t:this.instance_11},{t:this.instance_213},{t:this.instance_212},{t:this.instance_211},{t:this.instance_210},{t:this.instance_209},{t:this.instance_208},{t:this.instance_207},{t:this.instance_206},{t:this.instance_205},{t:this.instance_204},{t:this.instance_203},{t:this.instance_202},{t:this.instance_201},{t:this.instance_51},{t:this.instance_200},{t:this.instance_199},{t:this.instance_198},{t:this.instance_197},{t:this.instance_196},{t:this.instance_195},{t:this.instance_194},{t:this.instance_193},{t:this.instance_192}]},5).to({state:[{t:this.instance_237},{t:this.instance_11},{t:this.instance_213},{t:this.instance_236},{t:this.instance_235},{t:this.instance_234},{t:this.instance_233},{t:this.instance_232},{t:this.instance_231},{t:this.instance_230},{t:this.instance_229},{t:this.instance_228},{t:this.instance_227},{t:this.instance_226},{t:this.instance_225},{t:this.instance_51},{t:this.instance_224},{t:this.instance_223},{t:this.instance_222},{t:this.instance_221},{t:this.instance_220},{t:this.instance_219},{t:this.instance_218},{t:this.instance_217},{t:this.instance_216},{t:this.instance_215},{t:this.instance_214}]},5).to({state:[{t:this.instance_237},{t:this.instance_11},{t:this.instance_261},{t:this.instance_260},{t:this.instance_259},{t:this.instance_258},{t:this.instance_257},{t:this.instance_256},{t:this.instance_255},{t:this.instance_254},{t:this.instance_253},{t:this.instance_252},{t:this.instance_251},{t:this.instance_250},{t:this.instance_249},{t:this.instance_51},{t:this.instance_248},{t:this.instance_247},{t:this.instance_246},{t:this.instance_245},{t:this.instance_244},{t:this.instance_243},{t:this.instance_242},{t:this.instance_241},{t:this.instance_240},{t:this.instance_239},{t:this.instance_238}]},5).to({state:[{t:this.instance_286},{t:this.instance_11},{t:this.instance_261},{t:this.instance_285},{t:this.instance_284},{t:this.instance_283},{t:this.instance_282},{t:this.instance_281},{t:this.instance_280},{t:this.instance_279},{t:this.instance_278},{t:this.instance_277},{t:this.instance_276},{t:this.instance_275},{t:this.instance_274},{t:this.instance_51},{t:this.instance_273},{t:this.instance_272},{t:this.instance_271},{t:this.instance_270},{t:this.instance_269},{t:this.instance_268},{t:this.instance_267},{t:this.instance_266},{t:this.instance_265},{t:this.instance_264},{t:this.instance_263},{t:this.instance_262}]},5).to({state:[{t:this.instance_312},{t:this.instance_11},{t:this.instance_261},{t:this.instance_311},{t:this.instance_310},{t:this.instance_309},{t:this.instance_308},{t:this.instance_307},{t:this.instance_306},{t:this.instance_305},{t:this.instance_304},{t:this.instance_303},{t:this.instance_302},{t:this.instance_301},{t:this.instance_300},{t:this.instance_51},{t:this.instance_299},{t:this.instance_298},{t:this.instance_297},{t:this.instance_296},{t:this.instance_295},{t:this.instance_294},{t:this.instance_293},{t:this.instance_292},{t:this.instance_291},{t:this.instance_290},{t:this.instance_289},{t:this.instance_288},{t:this.instance_287}]},5).to({state:[{t:this.instance_312},{t:this.instance_11},{t:this.instance_339},{t:this.instance_338},{t:this.instance_337},{t:this.instance_336},{t:this.instance_335},{t:this.instance_334},{t:this.instance_333},{t:this.instance_332},{t:this.instance_331},{t:this.instance_330},{t:this.instance_329},{t:this.instance_328},{t:this.instance_327},{t:this.instance_51},{t:this.instance_326},{t:this.instance_325},{t:this.instance_324},{t:this.instance_323},{t:this.instance_322},{t:this.instance_321},{t:this.instance_320},{t:this.instance_319},{t:this.instance_318},{t:this.instance_317},{t:this.instance_316},{t:this.instance_315},{t:this.instance_314},{t:this.instance_313}]},5).to({state:[{t:this.instance_367},{t:this.instance_11},{t:this.instance_339},{t:this.instance_366},{t:this.instance_365},{t:this.instance_364},{t:this.instance_363},{t:this.instance_362},{t:this.instance_361},{t:this.instance_360},{t:this.instance_359},{t:this.instance_358},{t:this.instance_357},{t:this.instance_356},{t:this.instance_355},{t:this.instance_51},{t:this.instance_354},{t:this.instance_353},{t:this.instance_352},{t:this.instance_351},{t:this.instance_350},{t:this.instance_349},{t:this.instance_348},{t:this.instance_347},{t:this.instance_346},{t:this.instance_345},{t:this.instance_344},{t:this.instance_343},{t:this.instance_342},{t:this.instance_341},{t:this.instance_340}]},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(525.7,335.7,413.5,283.7);
// library properties:
lib.properties = {
	id: '0EC862F10BF19F4B95B042A4E107D499',
	width: 960,
	height: 640,
	fps: 10,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/dfs_atlas_.png", id:"dfs_atlas_"},
		{src:"images/dfs_atlas_2.png", id:"dfs_atlas_2"},
		{src:"images/dfs_atlas_3.png", id:"dfs_atlas_3"},
		{src:"images/dfs_atlas_4.png", id:"dfs_atlas_4"},
		{src:"images/dfs_atlas_5.png", id:"dfs_atlas_5"},
		{src:"images/dfs_atlas_6.png", id:"dfs_atlas_6"},
		{src:"images/dfs_atlas_7.png", id:"dfs_atlas_7"},
		{src:"images/dfs_atlas_8.png", id:"dfs_atlas_8"},
		{src:"images/dfs_atlas_9.png", id:"dfs_atlas_9"},
		{src:"images/dfs_atlas_10.png", id:"dfs_atlas_10"},
		{src:"images/dfs_atlas_11.png", id:"dfs_atlas_11"},
		{src:"images/dfs_atlas_12.png", id:"dfs_atlas_12"},
		{src:"images/dfs_atlas_13.png", id:"dfs_atlas_13"},
		{src:"images/dfs_atlas_14.png", id:"dfs_atlas_14"},
		{src:"images/dfs_atlas_15.png", id:"dfs_atlas_15"},
		{src:"images/dfs_atlas_16.png", id:"dfs_atlas_16"},
		{src:"images/dfs_atlas_17.png", id:"dfs_atlas_17"},
		{src:"images/dfs_atlas_18.png", id:"dfs_atlas_18"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0EC862F10BF19F4B95B042A4E107D499'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;