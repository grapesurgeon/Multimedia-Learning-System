(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Binary Search_atlas_", frames: [[1194,0,325,458],[327,432,325,458],[0,432,325,458],[654,669,208,81],[838,752,90,90],[0,144,1192,142],[108,892,52,57],[54,892,52,57],[192,951,30,57],[160,951,30,57],[0,892,52,57],[162,892,52,57],[216,892,52,57],[270,892,52,57],[654,460,304,75],[224,951,30,57],[256,951,30,57],[288,951,30,57],[320,951,30,57],[352,951,30,57],[384,951,30,57],[416,951,30,57],[448,951,30,57],[0,288,1192,142],[324,892,52,57],[378,892,52,57],[480,951,30,57],[512,951,30,57],[432,892,52,57],[654,844,52,57],[930,791,52,57],[972,673,52,57],[960,432,204,75],[836,844,30,57],[804,844,30,57],[486,892,30,57],[518,892,30,57],[550,892,30,57],[582,892,30,57],[614,892,30,57],[708,844,30,57],[0,0,1192,142],[864,614,52,57],[918,614,52,57],[740,844,30,57],[868,844,30,57],[864,673,52,57],[918,673,52,57],[930,732,52,57],[972,614,52,57],[826,537,204,75],[772,844,30,57],[128,951,30,57],[96,951,30,57],[64,951,30,57],[32,951,30,57],[0,951,30,57],[646,903,30,57],[900,850,30,57],[654,537,170,130],[654,752,90,90],[746,752,90,90]]}
];


// symbols:



(lib.CachedTexturedBitmap_106 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_107 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_108 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_109 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_110 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_113 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_114 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_115 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_116 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_117 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_118 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_119 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_120 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_121 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_122 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_123 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_124 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_125 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_126 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_127 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_128 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_129 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_130 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_131 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_132 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_133 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_134 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_135 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_136 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_137 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_138 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_139 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_140 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_141 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_142 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_143 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_144 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_145 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_146 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_147 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_148 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_149 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_150 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_151 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_152 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_153 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_154 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_155 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_156 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_157 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_158 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_159 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_160 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_161 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_162 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_163 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_164 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_165 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_166 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_167 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_169 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_171 = function() {
	this.initialize(ss["Binary Search_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_171();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_171();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_169();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_169();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-22.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-22.5,45,45);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_167();
	this.instance.parent = this;
	this.instance.setTransform(-2.5,-2.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,85,65);


// stage content:
(lib.BinarySearch = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(31);
		}
	}
	this.frame_59 = function() {
		this.stop();
		
		this.nextBtn.addEventListener("click", handleNext.bind(this));
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handleNext(){
			this.gotoAndPlay(61);
		}
		
		function handlePrev(){
			this.gotoAndPlay(29)
		}
	}
	this.frame_89 = function() {
		this.stop();
		
		this.prevBtn.addEventListener("click", handlePrev.bind(this));
		
		function handlePrev(){
			this.gotoAndPlay(119)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(30).call(this.frame_89).wait(1));

	// Button
	this.nextBtn = new lib.Symbol1();
	this.nextBtn.name = "nextBtn";
	this.nextBtn.parent = this;
	this.nextBtn.setTransform(910,580,1,1,0,0,0,40,30);
	new cjs.ButtonHelper(this.nextBtn, 0, 1, 1);

	this.instance = new lib.CachedTexturedBitmap_106();
	this.instance.parent = this;
	this.instance.setTransform(23.2,73.7,0.5,0.5);

	this.prevBtn = new lib.Symbol1();
	this.prevBtn.name = "prevBtn";
	this.prevBtn.parent = this;
	this.prevBtn.setTransform(50,580,1,1,180,0,0,40,30);
	new cjs.ButtonHelper(this.prevBtn, 0, 1, 1);

	this.instance_1 = new lib.CachedTexturedBitmap_107();
	this.instance_1.parent = this;
	this.instance_1.setTransform(23.2,73.7,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_109();
	this.instance_2.parent = this;
	this.instance_2.setTransform(535,302.7,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_108();
	this.instance_3.parent = this;
	this.instance_3.setTransform(23.2,73.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance},{t:this.nextBtn}]},29).to({state:[{t:this.instance_1},{t:this.nextBtn},{t:this.prevBtn}]},30).to({state:[{t:this.instance_3},{t:this.prevBtn},{t:this.instance_2}]},30).wait(1));

	// right
	this.instance_4 = new lib.CachedTexturedBitmap_110();
	this.instance_4.parent = this;
	this.instance_4.setTransform(710.1,482.65,0.5,0.5);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).wait(61));

	// mid
	this.instance_5 = new lib.CachedTexturedBitmap_171();
	this.instance_5.parent = this;
	this.instance_5.setTransform(409.1,483.65,0.5,0.5);

	this.instance_6 = new lib.Tween9("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(431.6,506.15);
	this.instance_6._off = true;

	this.instance_7 = new lib.Tween10("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(579.6,506.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},29).to({state:[{t:this.instance_6}]},30).to({state:[{t:this.instance_7}]},30).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(59).to({_off:false},0).to({_off:true,x:579.6},30).wait(1));

	// left
	this.instance_8 = new lib.Tween6("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(208.2,505.95);
	this.instance_8._off = true;

	this.instance_9 = new lib.Tween7("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(508.2,505.95);

	this.instance_10 = new lib.CachedTexturedBitmap_169();
	this.instance_10.parent = this;
	this.instance_10.setTransform(485.7,483.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},29).to({state:[{t:this.instance_9}]},30).to({state:[{t:this.instance_10}]},30).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(29).to({_off:false},0).to({_off:true,x:508.2},30).wait(31));

	// Array
	this.instance_11 = new lib.CachedTexturedBitmap_130();
	this.instance_11.parent = this;
	this.instance_11.setTransform(723.4,486.8,0.5,0.5);

	this.instance_12 = new lib.CachedTexturedBitmap_129();
	this.instance_12.parent = this;
	this.instance_12.setTransform(651,486.8,0.5,0.5);

	this.instance_13 = new lib.CachedTexturedBitmap_128();
	this.instance_13.parent = this;
	this.instance_13.setTransform(573.4,486.8,0.5,0.5);

	this.instance_14 = new lib.CachedTexturedBitmap_127();
	this.instance_14.parent = this;
	this.instance_14.setTransform(501,486.8,0.5,0.5);

	this.instance_15 = new lib.CachedTexturedBitmap_126();
	this.instance_15.parent = this;
	this.instance_15.setTransform(423.4,486.8,0.5,0.5);

	this.instance_16 = new lib.CachedTexturedBitmap_125();
	this.instance_16.parent = this;
	this.instance_16.setTransform(351,486.8,0.5,0.5);

	this.instance_17 = new lib.CachedTexturedBitmap_124();
	this.instance_17.parent = this;
	this.instance_17.setTransform(273.4,486.8,0.5,0.5);

	this.instance_18 = new lib.CachedTexturedBitmap_123();
	this.instance_18.parent = this;
	this.instance_18.setTransform(201,486.8,0.5,0.5);

	this.instance_19 = new lib.CachedTexturedBitmap_122();
	this.instance_19.parent = this;
	this.instance_19.setTransform(49.05,36.45,0.5,0.5);

	this.instance_20 = new lib.CachedTexturedBitmap_121();
	this.instance_20.parent = this;
	this.instance_20.setTransform(723.4,420,0.5,0.5);

	this.instance_21 = new lib.CachedTexturedBitmap_120();
	this.instance_21.parent = this;
	this.instance_21.setTransform(651,420,0.5,0.5);

	this.instance_22 = new lib.CachedTexturedBitmap_119();
	this.instance_22.parent = this;
	this.instance_22.setTransform(573.4,420,0.5,0.5);

	this.instance_23 = new lib.CachedTexturedBitmap_118();
	this.instance_23.parent = this;
	this.instance_23.setTransform(501,420,0.5,0.5);

	this.instance_24 = new lib.CachedTexturedBitmap_117();
	this.instance_24.parent = this;
	this.instance_24.setTransform(273.4,420,0.5,0.5);

	this.instance_25 = new lib.CachedTexturedBitmap_116();
	this.instance_25.parent = this;
	this.instance_25.setTransform(201,420,0.5,0.5);

	this.instance_26 = new lib.CachedTexturedBitmap_115();
	this.instance_26.parent = this;
	this.instance_26.setTransform(423.4,420,0.5,0.5);

	this.instance_27 = new lib.CachedTexturedBitmap_114();
	this.instance_27.parent = this;
	this.instance_27.setTransform(351,420,0.5,0.5);

	this.instance_28 = new lib.CachedTexturedBitmap_113();
	this.instance_28.parent = this;
	this.instance_28.setTransform(174.5,399.5,0.5,0.5);

	this.instance_29 = new lib.CachedTexturedBitmap_148();
	this.instance_29.parent = this;
	this.instance_29.setTransform(723.4,491.8,0.5,0.5);

	this.instance_30 = new lib.CachedTexturedBitmap_147();
	this.instance_30.parent = this;
	this.instance_30.setTransform(651,491.8,0.5,0.5);

	this.instance_31 = new lib.CachedTexturedBitmap_146();
	this.instance_31.parent = this;
	this.instance_31.setTransform(573.4,491.8,0.5,0.5);

	this.instance_32 = new lib.CachedTexturedBitmap_145();
	this.instance_32.parent = this;
	this.instance_32.setTransform(501,491.8,0.5,0.5);

	this.instance_33 = new lib.CachedTexturedBitmap_144();
	this.instance_33.parent = this;
	this.instance_33.setTransform(423.4,491.8,0.5,0.5);

	this.instance_34 = new lib.CachedTexturedBitmap_143();
	this.instance_34.parent = this;
	this.instance_34.setTransform(351,491.8,0.5,0.5);

	this.instance_35 = new lib.CachedTexturedBitmap_142();
	this.instance_35.parent = this;
	this.instance_35.setTransform(273.4,491.8,0.5,0.5);

	this.instance_36 = new lib.CachedTexturedBitmap_141();
	this.instance_36.parent = this;
	this.instance_36.setTransform(201,491.8,0.5,0.5);

	this.instance_37 = new lib.CachedTexturedBitmap_140();
	this.instance_37.parent = this;
	this.instance_37.setTransform(49.05,36.45,0.5,0.5);

	this.instance_38 = new lib.CachedTexturedBitmap_139();
	this.instance_38.parent = this;
	this.instance_38.setTransform(723.4,420,0.5,0.5);

	this.instance_39 = new lib.CachedTexturedBitmap_138();
	this.instance_39.parent = this;
	this.instance_39.setTransform(651,420,0.5,0.5);

	this.instance_40 = new lib.CachedTexturedBitmap_137();
	this.instance_40.parent = this;
	this.instance_40.setTransform(573.4,420,0.5,0.5);

	this.instance_41 = new lib.CachedTexturedBitmap_136();
	this.instance_41.parent = this;
	this.instance_41.setTransform(501,420,0.5,0.5);

	this.instance_42 = new lib.CachedTexturedBitmap_135();
	this.instance_42.parent = this;
	this.instance_42.setTransform(273.4,420,0.5,0.5);

	this.instance_43 = new lib.CachedTexturedBitmap_134();
	this.instance_43.parent = this;
	this.instance_43.setTransform(201,420,0.5,0.5);

	this.instance_44 = new lib.CachedTexturedBitmap_133();
	this.instance_44.parent = this;
	this.instance_44.setTransform(423.4,420,0.5,0.5);

	this.instance_45 = new lib.CachedTexturedBitmap_132();
	this.instance_45.parent = this;
	this.instance_45.setTransform(351,420,0.5,0.5);

	this.instance_46 = new lib.CachedTexturedBitmap_131();
	this.instance_46.parent = this;
	this.instance_46.setTransform(174.5,399.5,0.5,0.5);

	this.instance_47 = new lib.CachedTexturedBitmap_166();
	this.instance_47.parent = this;
	this.instance_47.setTransform(723.4,491.8,0.5,0.5);

	this.instance_48 = new lib.CachedTexturedBitmap_165();
	this.instance_48.parent = this;
	this.instance_48.setTransform(651,491.8,0.5,0.5);

	this.instance_49 = new lib.CachedTexturedBitmap_164();
	this.instance_49.parent = this;
	this.instance_49.setTransform(573.4,491.8,0.5,0.5);

	this.instance_50 = new lib.CachedTexturedBitmap_163();
	this.instance_50.parent = this;
	this.instance_50.setTransform(501,491.8,0.5,0.5);

	this.instance_51 = new lib.CachedTexturedBitmap_162();
	this.instance_51.parent = this;
	this.instance_51.setTransform(423.4,491.8,0.5,0.5);

	this.instance_52 = new lib.CachedTexturedBitmap_161();
	this.instance_52.parent = this;
	this.instance_52.setTransform(351,491.8,0.5,0.5);

	this.instance_53 = new lib.CachedTexturedBitmap_160();
	this.instance_53.parent = this;
	this.instance_53.setTransform(273.4,491.8,0.5,0.5);

	this.instance_54 = new lib.CachedTexturedBitmap_159();
	this.instance_54.parent = this;
	this.instance_54.setTransform(201,491.8,0.5,0.5);

	this.instance_55 = new lib.CachedTexturedBitmap_158();
	this.instance_55.parent = this;
	this.instance_55.setTransform(49.05,36.45,0.5,0.5);

	this.instance_56 = new lib.CachedTexturedBitmap_157();
	this.instance_56.parent = this;
	this.instance_56.setTransform(723.4,420,0.5,0.5);

	this.instance_57 = new lib.CachedTexturedBitmap_156();
	this.instance_57.parent = this;
	this.instance_57.setTransform(651,420,0.5,0.5);

	this.instance_58 = new lib.CachedTexturedBitmap_155();
	this.instance_58.parent = this;
	this.instance_58.setTransform(573.4,420,0.5,0.5);

	this.instance_59 = new lib.CachedTexturedBitmap_154();
	this.instance_59.parent = this;
	this.instance_59.setTransform(501,420,0.5,0.5);

	this.instance_60 = new lib.CachedTexturedBitmap_153();
	this.instance_60.parent = this;
	this.instance_60.setTransform(273.4,420,0.5,0.5);

	this.instance_61 = new lib.CachedTexturedBitmap_152();
	this.instance_61.parent = this;
	this.instance_61.setTransform(201,420,0.5,0.5);

	this.instance_62 = new lib.CachedTexturedBitmap_151();
	this.instance_62.parent = this;
	this.instance_62.setTransform(423.4,420,0.5,0.5);

	this.instance_63 = new lib.CachedTexturedBitmap_150();
	this.instance_63.parent = this;
	this.instance_63.setTransform(351,420,0.5,0.5);

	this.instance_64 = new lib.CachedTexturedBitmap_149();
	this.instance_64.parent = this;
	this.instance_64.setTransform(174.5,399.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11}]},1).to({state:[{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29}]},28).to({state:[{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47}]},60).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,952.5,612.5);
// library properties:
lib.properties = {
	id: '2EC0F2D9318F2843B3DA8AFC2DD0D1E2',
	width: 960,
	height: 640,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Binary Search_atlas_.png", id:"Binary Search_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2EC0F2D9318F2843B3DA8AFC2DD0D1E2'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;